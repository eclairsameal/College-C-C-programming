<?php

  $servername = "localhost";
  $username = "web";
  $password = "web123";

  $conn = mysqli_connect($servername, $username, $password);
  if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
  }
  mysqli_set_charset($conn,"utf8");
  $database = mysqli_select_db($conn, "trade");
 

  $operation = $_REQUEST['operation'];
  $ticker = $_REQUEST['ticker'];
  $company = $_REQUEST['company'];
  $price = $_REQUEST['price'];

  if ($operation == 'Insert') {
    if ($ticker != "" && $company != "" && $price != "") {
       $query = "insert into Stock values ('$ticker', '$company', $price)";
    }
  } else if ($operation == 'Delete') {
      $query = "delete from Stock where ticker = '$ticker'";
  } else if ($operation == 'Search')
     $query = "select * from Stock where price < $price";
  else if ($operation == 'List')
     $query = "select * from stock";

  $result = mysqli_query($conn, $query); 
  if ($operation == 'Insert') print("Insert successfully!");
  else if ($operation == 'Delete')  print("Delete successfully!");
  else {
  if ($result) {
    $output = array();
    while($row = mysqli_fetch_assoc($result)) $output[] = $row;

    // Use urlencode to workaround for json_encode without JSON_UNESCAPED_UNICODE
    array_walk_recursive($output, 
      function(&$value, $key) {
        if (is_string($value)) $value = urlencode($value);
      }
    );
    
    print(urldecode(json_encode($output)));
  } else print "No result!";
  }
  mysqli_close($conn);
?>