CREATE TABLE stock (
  ticker char(6) primary key not null,
  company varchar(40) not null,
  price decimal not null
);

