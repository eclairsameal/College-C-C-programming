package tw.edu.chu.httpurlpostget;

import android.os.AsyncTask;
import android.widget.Toast;
import  android.content.Context;
import org.json.JSONObject;

public class RequestAsync extends AsyncTask<String,String,String> {
    private String url = "140.126.5.24/trade";
    private Context context;
    public RequestAsync(Context c) {
        context = c;
    }
    @Override
    protected String doInBackground(String... strings) {
        try {
            //GET Request
            //return RequestHandler.sendGet("https://prodevsblog.com/android_get.php");

            // POST Request
            JSONObject postDataParams = new JSONObject();
            postDataParams.put("name", "Manjeet");
            postDataParams.put("email", "manjeet@gmail.com");
            postDataParams.put("phone", "+1111111111");

            return RequestHandler.sendPost("http://" + url + "/android_post.php",postDataParams);
        }
        catch(Exception e){
            return new String("Exception: " + e.getMessage());
        }
    }

    @Override
    protected void onPostExecute(String s) {
        if(s!=null){
            Toast.makeText(context.getApplicationContext(), s, Toast.LENGTH_LONG).show();
        }
    }
}
