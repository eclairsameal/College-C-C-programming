package tw.edu.chu.httpurlpostform;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

import org.json.JSONObject;

public class RequestAsync extends AsyncTask<String,String,String> {
    private String url = "140.126.10.81/trade";
    private Context context;
    public RequestAsync(Context c) {
        context = c;
    }
    @Override
    protected String doInBackground(String... strings) {
        try {
            String ticker = strings[0], company = strings[1], price = strings[2];
            // POST Request
            JSONObject postDataParams = new JSONObject();
            postDataParams.put("ticker", ticker);
            postDataParams.put("company", company);
            postDataParams.put("price", price);

            return RequestHandler.sendPost("http://" + url + "/android_post.php",postDataParams);
        }
        catch(Exception e){
            return new String("Exception: " + e.getMessage());
        }
    }

    @Override
    protected void onPostExecute(String s) {
        if(s!=null){
            MainActivity mainActivity = (MainActivity) context;
            mainActivity.showResult(s);
        }
    }
}
