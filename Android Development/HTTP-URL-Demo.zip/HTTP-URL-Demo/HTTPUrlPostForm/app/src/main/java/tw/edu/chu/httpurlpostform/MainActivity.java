package tw.edu.chu.httpurlpostform;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.AsyncTask;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void post(View v) {
        EditText edtTicker = (EditText) findViewById(R.id.editText1);
        EditText edtCompany = (EditText) findViewById(R.id.editText2);
        EditText edtPrice = (EditText) findViewById(R.id.editText3);
        String ticker = edtTicker.getText().toString(), company = edtCompany.getText().toString(), price = edtPrice.getText().toString();
        if (!ticker.trim().equalsIgnoreCase("") && !company.trim().equalsIgnoreCase("") &&
           !price.trim().equalsIgnoreCase(""))
          new RequestAsync(this).execute(ticker, company, price);
    }

    public void showResult(String s) {
        TextView tv = (TextView) findViewById(R.id.textView1);
        tv.setText(s);
    }
}
