package tw.edu.chu.httppostdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class MainActivity extends AppCompatActivity {

    TextView content;
    EditText edtName, edtEmail, edtLogin, edtPass;
    String name, email, login, pass;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        content    =   (TextView)findViewById( R.id.content );
        edtName      =   (EditText)findViewById(R.id.name);
        edtEmail      =   (EditText)findViewById(R.id.email);
        edtLogin      =    (EditText)findViewById(R.id.loginname);
        edtPass       =   (EditText)findViewById(R.id.password);

        Button saveme=(Button)findViewById(R.id.save);
        saveme.setOnClickListener(new Button.OnClickListener(){
            public void onClick(View v) {
               name = edtName.getText().toString();
               email   = edtEmail.getText().toString();
               login   = edtLogin.getText().toString();
               pass   = edtPass.getText().toString();
               new PostAsync(MainActivity.this).execute(name, email, login, pass);
            }
        });
    }
    public void showResult(String s) {
        TextView tv = (TextView) findViewById(R.id.content);
        tv.setText(s);
    }
}
