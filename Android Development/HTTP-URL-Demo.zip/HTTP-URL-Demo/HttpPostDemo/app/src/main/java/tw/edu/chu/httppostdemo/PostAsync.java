package tw.edu.chu.httppostdemo;

import android.content.Context;
import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class PostAsync extends AsyncTask<String,String,String> {

    private Context context;

    public String dataEncoder(String tag, String s) {
        try {
            return URLEncoder.encode(tag, "UTF-8") + "=" + URLEncoder.encode(s, "UTF-8");
        } catch(UnsupportedEncodingException e) {
            return e.toString();
        }
    }
    public PostAsync(Context c) {
        context = c;
    }
    @Override
    protected String doInBackground(String... args) {
       String name = args[0], email = args[1], login = args[2], pass = args[3];

        // Create data variable for sent values to server
        String data = dataEncoder("name", name) + "&" + dataEncoder("email", email) + "&" +
                      dataEncoder("user", login) + "&" + dataEncoder("pass", pass);

        String text = "";
        BufferedReader reader=null;

        // Send data
        try
        {
            // Defined URL  where to send data
            URL url = new URL("http://140.126.5.24/trade/httppost.php");
            // Send POST data request
            URLConnection conn = url.openConnection();
            conn.setDoOutput(true);
            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write(data);
            wr.flush();
            // Get the server response
            reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line = null;
            // Read Server Response
            while((line = reader.readLine()) != null)
            {
                // Append server response in string
                sb.append(line + "\n");
            }
            text = sb.toString();
        }
        catch(Exception ex) {
        }
        finally {
            try {
                reader.close();
            }
            catch(Exception ex) {}
        }
        // Show response on activity
        return text;
    }

    @Override
    protected void onPostExecute(String s) {
        if(s!=null){
            MainActivity mainActivity = (MainActivity) context;
            mainActivity.showResult(s);
        }
    }

}
