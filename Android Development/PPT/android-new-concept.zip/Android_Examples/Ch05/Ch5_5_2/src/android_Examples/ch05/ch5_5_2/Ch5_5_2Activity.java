package android_Examples.ch05.ch5_5_2;

import android.app.Activity;
import android.os.Bundle;

public class Ch5_5_2Activity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
}