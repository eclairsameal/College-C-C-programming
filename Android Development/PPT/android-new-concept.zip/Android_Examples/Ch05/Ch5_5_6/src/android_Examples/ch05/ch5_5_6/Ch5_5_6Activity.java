package android_Examples.ch05.ch5_5_6;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Ch5_5_6Activity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // setContentView(R.layout.main);
        // �إ�TextView����
        TextView lbl01 = new TextView(this);
        lbl01.setText("���|�w");
        lbl01.setTextSize(20);
        lbl01.setGravity(Gravity.CENTER);
        TextView lbl02 = new TextView(this);
        lbl02.setText("������");
        lbl02.setTextSize(20);
        lbl02.setGravity(Gravity.LEFT);
        // �إ�LinearLayout����
        LinearLayout ll = new LinearLayout(this);
        // ���w�����t�m����V�M�e,��
        ll.setOrientation(LinearLayout.VERTICAL);
        ll.setLayoutParams(new LayoutParams(
        		               LayoutParams.FILL_PARENT,
        		               LayoutParams.FILL_PARENT));
        ll.addView(lbl01);  // �[�JView����
        ll.addView(lbl02);
        setContentView(ll); // ���w��ܪ�����
    }
}