package android_Examples.ch05.ch5_2;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

public class Ch5_2Activity extends Activity {
    private static final String TAG = "Ch5_2";
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        Log.d(TAG, "ActivityCh5_2:onCreate");
    }
	@Override
	protected void onStart() {
		super.onStart();
		Log.d(TAG, "ActivityCh5_2:onStart");
	}	
	@Override
	protected void onResume() {
		super.onResume();
		Log.d(TAG, "ActivityCh5_2:onResume");
	}
	@Override
	protected void onStop() {
		super.onStop();
		Log.d(TAG, "ActivityCh5_2:onStop");
	}
	@Override
	protected void onPause() {
		super.onPause();
		Log.d(TAG, "ActivityCh5_2:onPause");
	}
	@Override
	protected void onRestart() {
		super.onRestart();
		Log.d(TAG, "ActivityCh5_2:onReStart");
	}
	@Override
	protected void onDestroy() {
		super.onDestroy();
		Log.d(TAG, "ActivityCh5_2:onDestroy");
	}
}