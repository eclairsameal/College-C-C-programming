package android_Examples.ch06.ch6_3_3;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ToggleButton;

public class Ch6_3_3Activity extends Activity 
                 implements OnCheckedChangeListener {
	private ToggleButton toggle;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        toggle = (ToggleButton) findViewById(R.id.toggleBtn);
        // ���U��ť�̪��󬰦ۤv
        toggle.setOnCheckedChangeListener(this);
    }
	// ��@������k
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		if (isChecked) 
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		else
		    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);		
	}    
};