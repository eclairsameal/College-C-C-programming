package android_Examples.ch06.ch6_4;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Ch6_4Activity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        // ��XButton����
        Button btn = (Button) findViewById(R.id.btn1);
        // ���U��ť�̪���
        btn.setOnClickListener(listener);
    }
    // �إ߶�ť�̪���
    View.OnClickListener listener = new View.OnClickListener() {
    	public void onClick(View v) {
    		double height, weight, bmi;
    		// ���o��J��
    		EditText txtHeight = (EditText) findViewById(R.id.txtHeight);
    		EditText txtWeight = (EditText) findViewById(R.id.txtWeight);
    		height = Double.parseDouble(txtHeight.getText().toString());
    		weight = Double.parseDouble(txtWeight.getText().toString());
    		// �p��BMI
    		height = height / 100.00;
    		bmi = weight / (height * height);
    		// ���BMI
    		TextView output = (TextView) findViewById(R.id.lblOutput);
    		output.setText(Double.toString(bmi));    		
    	}
    };
}