package android_Examples.ch06.ch6_3_2;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class Ch6_3_2Activity extends Activity {
	private ImageButton imgBtn1, imgBtn2, imgBtn3;
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        imgBtn1 = (ImageButton) findViewById(R.id.imgBtn1);
        imgBtn2 = (ImageButton) findViewById(R.id.imgBtn2);
        imgBtn3 = (ImageButton) findViewById(R.id.imgBtn3);
        // �إߨƥ�B�z����ť�̪���
        imgBtn1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
               imgBtn1.setImageResource(R.drawable.h11);
            }
        });
        imgBtn2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
               imgBtn2.setImageResource(R.drawable.d8);
            }
        });
        imgBtn3.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
               imgBtn3.setImageResource(R.drawable.h7);
            }
        });
    }
}