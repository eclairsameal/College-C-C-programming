package android_Examples.ch06.ch6_6;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class Ch6_6Activity extends Activity {
	private ImageView image;
	private RadioGroup radioGroup; 
	private RadioButton rdb01; 
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        // ���oView����
        radioGroup = (RadioGroup) findViewById(R.id.rdgImage);
        rdb01 = (RadioButton) findViewById(R.id.rdbRabbit);
        image = (ImageView) findViewById(R.id.image);
        // ���U��ť�̪���
        radioGroup.setOnCheckedChangeListener(listener);        
    }
    // �إ߶�ť�̪���
    private RadioGroup.OnCheckedChangeListener listener =
    		 new RadioGroup.OnCheckedChangeListener() { 
        public void onCheckedChanged(
        		     RadioGroup group, int checkedId) {
        	// �P�_��ܭ���RadioButton����
        	if (checkedId == rdb01.getId()) 
               image.setImageResource(R.drawable.rabbit);
        	else
        	   image.setImageResource(R.drawable.mouse);    
        } 
    };
}