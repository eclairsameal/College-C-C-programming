package android_Examples.ch06.ch6_5_1;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class Ch6_5_1Activity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    public void btn1_Click(View view) {
    	int amount = 0, quantity = 1;
    	// ���o��J���ƶq
    	EditText txtQuantity = (EditText) findViewById(R.id.txtQuantity);
		quantity = Integer.parseInt(txtQuantity.getText().toString());
		// �ˬd�Ŀ���ǩ���
    	CheckBox original = (CheckBox) findViewById(R.id.chkOriginal);
    	if (original.isChecked()) 
    	    amount += 250 * quantity;
    	CheckBox beef = (CheckBox) findViewById(R.id.chkBeef);
    	if (beef.isChecked()) 
    	    amount += 275 * quantity;
    	CheckBox seaFood = (CheckBox) findViewById(R.id.chkSeaFood);
    	if (seaFood.isChecked()) 
    	    amount += 350 * quantity;
    	// ��ܭq�ʪ��B
    	TextView output = (TextView) findViewById(R.id.lblOutput);
		output.setText(Integer.toString(amount));    	
    }
}