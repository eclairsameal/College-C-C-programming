package android_Examples.ch06.ch6_3_1;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Ch6_3_1Activity extends Activity {
	private int num1, num2;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        // �ϥζüƨ��o�I��
        num1 = (int)(Math.random()*12) + 1;
        num2 = (int)(Math.random()*12) + 1;
        // ���UButton����ť�̪���
        Button btn1 = (Button) findViewById(R.id.button1);
        btn1.setOnClickListener(btn1Listener);
        Button btn2 = (Button) findViewById(R.id.button2);
        btn2.setOnClickListener(btn2Listener);        
    }
    // button1����ť�̪���
    View.OnClickListener btn1Listener = new View.OnClickListener() {
    	public void onClick(View v) {
    		Toast.makeText(Ch6_3_1Activity.this, 
    		           Integer.toString(num1),
    	               Toast.LENGTH_SHORT).show();
    	}
    };
    // button2����ť�̪���
    View.OnClickListener btn2Listener = new View.OnClickListener() {
    	public void onClick(View v) {
    		Toast.makeText(Ch6_3_1Activity.this,
    				   Integer.toString(num2),
    	               Toast.LENGTH_SHORT).show();
    	}
    };
}