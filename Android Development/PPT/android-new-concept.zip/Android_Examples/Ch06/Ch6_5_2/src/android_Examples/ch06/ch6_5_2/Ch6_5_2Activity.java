package android_Examples.ch06.ch6_5_2;

import android.app.Activity;
import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class Ch6_5_2Activity extends Activity {
	private TextView output;
	private RadioGroup radioGroup; 
	private RadioButton rdb01,rdb02, rdb03, rdb04; 
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        // ���oView����
        output = (TextView) findViewById(R.id.lblOutput);
        radioGroup = (RadioGroup) findViewById(R.id.rdgSteak);
        rdb01 = (RadioButton) findViewById(R.id.rdbRare);
        rdb02 = (RadioButton) findViewById(R.id.rdbMedium);
        rdb03 = (RadioButton) findViewById(R.id.rdbMedWell);
        rdb04 = (RadioButton) findViewById(R.id.rdbWellDone);
        // ���U��ť�̪���
        radioGroup.setOnCheckedChangeListener(listener);
    }
    // �إ߶�ť�̪���
    private RadioGroup.OnCheckedChangeListener listener =
    		 new RadioGroup.OnCheckedChangeListener() { 
        public void onCheckedChanged(
        		     RadioGroup group, int checkedId) {
        	// �P�_��ܭ���RadioButton����
        	if (checkedId == rdb01.getId()) 
               output.setText(rdb01.getText());
        	else if (checkedId == rdb02.getId()) 
                   output.setText(rdb02.getText());
        	else if (checkedId == rdb03.getId()) 
                   output.setText(rdb03.getText());
        	else  output.setText(rdb04.getText()); 
        } 
    };
}