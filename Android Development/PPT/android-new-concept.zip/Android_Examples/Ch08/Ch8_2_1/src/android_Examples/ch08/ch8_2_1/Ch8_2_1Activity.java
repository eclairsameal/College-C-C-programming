package android_Examples.ch08.ch8_2_1;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class Ch8_2_1Activity extends Activity {
    private static final int MENU_ABOUT = 0;
    private static final int MENU_QUIT = 1;
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    @Override
	public boolean onCreateOptionsMenu(Menu menu) {
    	// �s�W��檺�ﶵ
		menu.add(Menu.NONE, MENU_ABOUT, 0, "����");
		menu.add(Menu.NONE, MENU_QUIT, 0, "����");
		return super.onCreateOptionsMenu(menu);
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch(item.getItemId()) { // �B�z�ﶵ
		case MENU_ABOUT: 
		   AlertDialog.Builder builder =
		          new AlertDialog.Builder(this); 
	       builder.setTitle("����")
	       .setMessage("����: 1.0��\n�@��: ���|�w")
	       .setPositiveButton("�T�w",null).show();          
		   break; 
		case MENU_QUIT:  
		   finish(); // �����{��
		   break; 
		} 
		return super.onOptionsItemSelected(item);
	}
}