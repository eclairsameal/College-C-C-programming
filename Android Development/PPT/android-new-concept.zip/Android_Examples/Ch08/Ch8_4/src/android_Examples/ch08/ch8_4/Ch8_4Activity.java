package android_Examples.ch08.ch8_4;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.widget.TextView;

public class Ch8_4Activity extends Activity {
    private static final int MENU_ABOUT = 0;
    private static final int MENU_QUIT  = 1;
    private static final int MENU_COLOR = 2;
    private static final int MENU_RED   = 3;
    private static final int MENU_YELLOW= 4;
    private static final int MENU_GREEN = 5;
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    @Override
	public boolean onCreateOptionsMenu(Menu menu) {
    	// �s�W�ﶵ
		menu.add(Menu.NONE, MENU_ABOUT, 0, "����")
		.setIcon(android.R.drawable.ic_menu_help);
		menu.add(Menu.NONE, MENU_QUIT, 0, "����")
		.setIcon(android.R.drawable.ic_menu_close_clear_cancel);		
		// �s�W�l���
		SubMenu submenu = menu.addSubMenu(Menu.NONE, MENU_COLOR, 0, "�I����m")
				         .setIcon(android.R.drawable.ic_menu_add);
		// �s�W�l��檺�ﶵ
		submenu.add(Menu.NONE, MENU_RED, 0, "����"); 
		submenu.add(Menu.NONE, MENU_YELLOW, 0, "����"); 
		submenu.add(Menu.NONE, MENU_GREEN, 0, "���"); 
		return super.onCreateOptionsMenu(menu);
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		TextView label = (TextView) findViewById(R.id.label1);
		switch(item.getItemId()) { 
		case MENU_ABOUT: 
		   AlertDialog.Builder builder =
		         new AlertDialog.Builder(this); 
	       builder.setTitle("����")
	       .setMessage("����: 1.0��\n�@��: ���|�w")
	       .setPositiveButton("�T�w",null).show();         
		   break; 
		case MENU_QUIT:  
		   finish(); // �����{��
		   break; 
		case MENU_RED:
      	  label.setBackgroundColor(Color.RED);
            break;
        case MENU_YELLOW:
      	  label.setBackgroundColor(Color.YELLOW);
            break;
        case MENU_GREEN:
      	  label.setBackgroundColor(Color.GREEN);
            break;   
		} 
		return super.onOptionsItemSelected(item);
	}
}