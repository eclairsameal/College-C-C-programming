package android_Examples.ch08.ch8_5;

import android.os.Bundle;
import android.preference.PreferenceActivity;

public class Ch8_5Activity extends PreferenceActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.preferences);
    }
}