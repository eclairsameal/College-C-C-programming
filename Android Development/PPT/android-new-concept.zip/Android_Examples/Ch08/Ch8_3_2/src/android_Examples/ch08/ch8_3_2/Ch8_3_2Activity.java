package android_Examples.ch08.ch8_3_2;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.view.ContextMenu.ContextMenuInfo;
import android.widget.Button;

public class Ch8_3_2Activity extends Activity {
	private Button btn;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        btn = (Button) findViewById(R.id.button1);
        // ���U������� 
        registerForContextMenu(btn); 
    }
	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
			ContextMenuInfo menuInfo) {
		super.onCreateContextMenu(menu, v, menuInfo);
		menu.setHeaderTitle("��ܫ��s���I����m");
		getMenuInflater().inflate(R.menu.contextmenu, menu);		
	}
	@Override
	public boolean onContextItemSelected(MenuItem item) {
		switch(item.getItemId()){
        case R.id.menu_red:
        	  btn.setBackgroundColor(Color.RED);
              break;
        case R.id.menu_yellow:
        	  btn.setBackgroundColor(Color.YELLOW);
              break;
        case R.id.menu_green:
        	  btn.setBackgroundColor(Color.GREEN);
              break;
        }      
		return super.onContextItemSelected(item);
	}
}