package android_Examples.ch08.ch8_1_2;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnLongClickListener;
import android.widget.Button;
import android.widget.TextView;

public class Ch8_1_2Activity extends Activity 
        implements View.OnClickListener, OnLongClickListener {
	private TextView label;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        label = (TextView) findViewById(R.id.label);
        Button btn = (Button) findViewById(R.id.button);
        btn.setOnClickListener(this);
        btn.setOnLongClickListener(this);
    }
	@Override
	public boolean onLongClick(View v) {
		label.setText("Ĳ�oLongClick�ƥ�...");
		return false; // Ĳ�oLongClick��AĲ�oClick�ƥ�
		// return true;  // �uĲ�oLongClick�ƥ�
	}	
	@Override
	public void onClick(View v) {
		label.setText("Ĳ�oClick�ƥ�...");		
	}
}