package android_Examples.ch08.ch8_2_4;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageButton;

public class Ch8_2_4Activity extends Activity {
	MenuDialog menuDialog;
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    @Override
	public boolean onKeyUp(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_MENU) {
			if (menuDialog == null)
				menuDialog = new MenuDialog(this);
			menuDialog.show(); // ���
			return true;
		}
		return super.onKeyUp(keyCode, event);
	}
    private class MenuDialog extends Dialog 
                    implements View.OnClickListener {
        ImageButton imgbtn01, imgbtn02;
        public MenuDialog(Context context) {
           super(context);
           setContentView(R.layout.mainmenu);
           setTitle("�ﶵ���");
           imgbtn01 = (ImageButton) findViewById(R.id.about);
           imgbtn01.setOnClickListener(this);
           imgbtn02 = (ImageButton) findViewById(R.id.quit);
           imgbtn02.setOnClickListener(this);
        }
        @Override
    	public boolean onKeyUp(int keyCode, KeyEvent event) {
    		if (keyCode == KeyEvent.KEYCODE_MENU) {
    			dismiss();
    			return true;
    		}
    		return super.onKeyUp(keyCode, event);
    	}
        public void onClick(View v) {
           if (v == imgbtn01) {
               dismiss();
               AlertDialog.Builder builder =
      		         new AlertDialog.Builder(Ch8_2_4Activity.this); 
      	       builder.setTitle("����")
      	       .setMessage("����: 1.0��\n�@��: ���|�w")
      	       .setPositiveButton("�T�w",null).show();     
           }    
           else {
        	   finish();        	   
           }	   
        }
    }
}