package android_Examples.ch08.ch8_2_3;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

public class Ch8_2_3Activity extends Activity {
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    @Override
	public boolean onCreateOptionsMenu(Menu menu) {
    	// �إ߿ﶵ��檺�ﶵ
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.mainmenu, menu);
		return super.onCreateOptionsMenu(menu);
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch(item.getItemId()) { 
		case R.id.about: 
		   AlertDialog.Builder builder =
		         new AlertDialog.Builder(this); 
	       builder.setTitle("����")
	       .setMessage("����: 1.0��\n�@��: ���|�w")
	       .setPositiveButton("�T�w",null).show();         
		   break; 
		case R.id.quit:  
		   finish(); // �����{��
		   break; 
		} 
		return super.onOptionsItemSelected(item);
	}
}