package android_Examples.ch08.ch8_1_3;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.widget.Toast;

public class Ch8_1_3Activity extends Activity {
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    @Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_DEL) {
			Toast.makeText(this, "���UDEL��...",
	               Toast.LENGTH_SHORT).show();
			return true;
		}			
		return super.onKeyDown(keyCode, event);
	}
	@Override
	public boolean onKeyUp(int keyCode, KeyEvent event) {
	    if (keyCode == KeyEvent.KEYCODE_MENU) {
			Toast.makeText(this, "���UMENU��...",
		           Toast.LENGTH_SHORT).show();
	        return true;
	     }
		return super.onKeyUp(keyCode, event);
	}
}