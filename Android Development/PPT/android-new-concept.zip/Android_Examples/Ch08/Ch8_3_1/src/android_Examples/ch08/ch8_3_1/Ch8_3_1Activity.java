package android_Examples.ch08.ch8_3_1;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

public class Ch8_3_1Activity extends Activity {
	private static final int MENU_RED = 0;
    private static final int MENU_YELLOW = 1;
    private static final int MENU_GREEN = 2;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        LinearLayout layout = (LinearLayout) findViewById(R.id.linear); 
        // ���U������� 
        registerForContextMenu(layout); 
    }
	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
			ContextMenuInfo menuInfo) {
		super.onCreateContextMenu(menu, v, menuInfo);
		menu.setHeaderTitle("��ܫ��s���I����m");
		// �s�W��檺�ﶵ
		menu.add(Menu.NONE, MENU_RED, 0, "����"); 
		menu.add(Menu.NONE, MENU_YELLOW, 0, "����"); 
		menu.add(Menu.NONE, MENU_GREEN, 0, "���"); 
	}
	@Override
	public boolean onContextItemSelected(MenuItem item) {
		Button btn = (Button) findViewById(R.id.button1);
        switch(item.getItemId()){
        case MENU_RED:
        	  btn.setBackgroundColor(Color.RED);
              break;
        case MENU_YELLOW:
        	  btn.setBackgroundColor(Color.YELLOW);
              break;
        case MENU_GREEN:
        	  btn.setBackgroundColor(Color.GREEN);
              break;
        }      
		return super.onContextItemSelected(item);
	}
}