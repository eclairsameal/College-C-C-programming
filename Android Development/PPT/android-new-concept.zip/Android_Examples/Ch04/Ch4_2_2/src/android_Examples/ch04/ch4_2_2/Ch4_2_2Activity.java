package android_Examples.ch04.ch4_2_2;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Ch4_2_2Activity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    // Button���󪺨ƥ�B�z
    public void button1_Click(View view) {
    	TextView output = (TextView) findViewById(R.id.txtOutput);
    	String str = "";
    	Counter c = new Counter(); // �إߪ���
    	// �I�s�L����k
    	str += "a(1)+b(2) = " + c.sum(1, 2);
    	str += "\na(1)+b(2)+c(3) = " + c.sum(1, 2, 3);
    	// ��y�I�s��k
    	int count = c.count(2).count(3.0).getCount();
    	str += "\n�ثe�p��: " + count;
    	output.setText(str);
    }
}
// Counter���O�ŧi
class Counter {
	private int count;
	// �غc�l
	public Counter() { count = 0; }
	// �L����k: ���P���A
	public Counter count(double num) {
		count += num;
		return this;
	}
	public Counter count(int num) {
		count += num;
		return this;
	}
	// ���o�p�ƭ�
	public int getCount() { return count; }
	// �L����k: ���P�ѼƭӼ�
	public int sum(int a, int b) {
		return a + b;
	}
	public int sum(int a, int b, int c) {
		return a + b + c;
	}	
}