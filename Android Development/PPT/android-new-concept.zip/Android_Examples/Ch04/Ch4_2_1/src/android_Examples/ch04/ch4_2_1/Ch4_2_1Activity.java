package android_Examples.ch04.ch4_2_1;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Ch4_2_1Activity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    // Button���󪺨ƥ�B�z
    public void button1_Click(View view) {
    	TextView output = (TextView) findViewById(R.id.txtOutput);
    	String str = "";
    	Customer joe;             // �ŧi�����ܼ�
    	joe = new Customer("���|�w","�s�_�]"); // �إߪ���
    	joe.age = 40;             // ���wpublic�����ܼ� 
    	str += joe.getLabelData();  // �I�s��k
    	str += "\nName: "+joe.getName();
    	str += "\nAddress: "+joe.getAddress();
    	str += "\nAge: "+joe.age;
    	output.setText(str);
    }
}