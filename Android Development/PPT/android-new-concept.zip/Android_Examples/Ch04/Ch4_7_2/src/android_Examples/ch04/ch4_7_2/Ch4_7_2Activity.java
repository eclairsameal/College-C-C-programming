package android_Examples.ch04.ch4_7_2;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class Ch4_7_2Activity extends Activity {
	private static final String TAG = "Ch4_7_2";
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    // Button���󪺨ƥ�B�z
    public void button1_Click(View view) {
    	Log.d(TAG, "�����: " + Thread.currentThread());
    	// �إ߰��������
    	SumThread st = new SumThread(150, "�����A");    	
    	st.start();   // �Ұʰ����
    	// �إ߰ΦW���h���O�ӱҰʰ����
    	new Thread("�����B") {
    		int length = 150;
    		// �������� 
    	    public void run() {
    	          long temp = 0;
    	          for (int i = 1; i <= length; i++) {
    	             try {  // �Ȱ��@�q�ɶ�
    	                Thread.sleep((int)(Math.random()*10));
    	             }
    	             catch(InterruptedException e){ } 
    	             temp += i;
    	          } 
    	          Log.d(TAG, Thread.currentThread() + "�`�M = " + temp);
    	    }
    	}.start(); // �Ұʰ����   	
    }
    class SumThread extends Thread {
       private long length;
       // �غc�l
       public SumThread(long length, String name) {
           super(name);
           this.length = length; 
       }
       // �������� 
       public void run() {
          long temp = 0;
          for (int i = 1; i <= length; i++) {
             try {  // �Ȱ��@�q�ɶ�
                Thread.sleep((int)(Math.random()*10));
             }
             catch(InterruptedException e){ } 
             temp += i;
          } 
          Log.d(TAG, Thread.currentThread() + "�`�M = " + temp);
       }
    }
}