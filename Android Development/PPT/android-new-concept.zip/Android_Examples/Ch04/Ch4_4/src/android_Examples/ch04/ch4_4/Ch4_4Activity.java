package android_Examples.ch04.ch4_4;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Ch4_4Activity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    // Button���󪺨ƥ�B�z
    public void button1_Click(View view) {
    	TextView output = (TextView) findViewById(R.id.txtOutput);
    	String str = "";
    	// �إߪ���
    	MyNumber app = new MyNumber();
    	str = app.result;
    	output.setText(str);
    }
    // MyNumber���O�ŧi
    class MyNumber {
       public String result;
       // �غc�l
       public MyNumber() {
          result = ( new MyInt(100) {
               public String getResult()
               {  return "��ƭȡG " + value; }
          }).getResult();
       }
       // MyInt���O�ŧi
       class MyInt {
          public int value;
          public MyInt(int v) { value = v; }
          public String getResult() { return "Int:"+value; }
       }
    }
}