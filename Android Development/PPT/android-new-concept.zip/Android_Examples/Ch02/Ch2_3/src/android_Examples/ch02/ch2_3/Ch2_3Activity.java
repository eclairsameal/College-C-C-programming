package android_Examples.ch02.ch2_3;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Ch2_3Activity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    
    public void button1_Click(View view) {
    	TextView output = (TextView) findViewById(R.id.txtOutput);
    	output.setText("�ĤG��Android���ε{��");
    }
}