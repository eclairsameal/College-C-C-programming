package android_Examples.ch07.ch7_2_2;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;

public class Ch7_2_2Activity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    // �ƥ�B�z�{��
    public void button1_Click(View view) {
    	AlertDialog.Builder builder = new AlertDialog.Builder(this); 
        builder.setTitle("�T�{")
          .setMessage("�T�{�������{��?")
          .setPositiveButton("�T�w",
        		new DialogInterface.OnClickListener() { 
                public void onClick(DialogInterface  
                               dialoginterface, int i) { 
                   finish();  // ��������
                } 
          }) 
          .setNegativeButton("����", null) 
          .show();
    }
}