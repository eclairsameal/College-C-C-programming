package android_Examples.ch07.ch7_2_4;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class Ch7_2_4Activity extends Activity {
	String[] items = {"Android", "iOS", "Windows Mobile"};
	boolean[] itemsChecked = new boolean[items.length];
    @Override
    public void onCreate(Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.main);
    }
    @Override
    protected Dialog onCreateDialog(int id) {
      switch (id) {
    	case 0: // �Ǧ^AlertDialog��ܤ��
    		return new AlertDialog.Builder(this)
    		.setTitle("�ФĿ�ﶵ?")
    		.setPositiveButton("�T�w",
    		 new DialogInterface.OnClickListener() { 
    	        public void onClick(DialogInterface  
    	                     dialoginterface, int i) {    	                  
    	           String msg = "";
    	           for (int index = 0; index < items.length; index++) {
    	           	  if (itemsChecked[index])
    	                  msg += items[index] + "\n";        	   
    	           }
    	           TextView output = (TextView) findViewById(R.id.lblOutput);
    	           output.setText(msg);
    	        } 
    	     }) 
    	    .setNegativeButton("����", null) 
    	    .setMultiChoiceItems(items,itemsChecked, 
    	     new DialogInterface.OnMultiChoiceClickListener() {
				public void onClick(DialogInterface dialog, int which, boolean isChecked) {
				   Toast.makeText(Ch7_2_4Activity.this, 
						items[which] + (isChecked ? " �Ŀ�": "�S���Ŀ�"),
		                Toast.LENGTH_SHORT).show();   	 
				}
			 })
    	    .create();
      }
      return null;
    }
    // button1�ƥ�B�z�{��
    public void button1_Click(View view) {    	
      showDialog(0); // ��ܹ�ܤ��        
    }
}