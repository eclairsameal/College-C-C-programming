package android_Examples.ch07.ch7_3_3;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Ch7_3_3Activity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);        
    }
    // button1�ƥ�B�z�{��
    public void button1_Click(View view) { 
    	// �إ�MyDialog��ܤ��
    	MyDialog myDialog = new MyDialog(this);
    	myDialog.setTitle("�ۭq��ܤ��");
		myDialog.show(); // ��ܹ�ܤ��
    }
}
// MyDialog���O���ۭq��ܤ��
class MyDialog extends Dialog implements View.OnClickListener {
	Button btn;
	public MyDialog(Context context) {
		super(context);
		setContentView(R.layout.dialog);		
		btn = (Button) findViewById(R.id.btn);
		btn.setOnClickListener(this);
	}
	// ��ܤ�����s���ƥ�B�z�{��
	public void onClick(View v) {
		if (v == btn)
		    dismiss();
	}
}