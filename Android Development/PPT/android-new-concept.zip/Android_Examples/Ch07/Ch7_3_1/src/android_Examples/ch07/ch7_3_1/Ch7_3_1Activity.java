package android_Examples.ch07.ch7_3_1;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class Ch7_3_1Activity extends Activity {
	String[] items = {"Android", "iOS", "Windows Mobile"};
	boolean[] itemsChecked = new boolean[items.length];
	private ProgressDialog pDialog;
	private int p = 0;
	private Handler pHandler;
    @Override
    public void onCreate(Bundle savedInstanceState) {
       super.onCreate(savedInstanceState);
       setContentView(R.layout.main);
       pHandler = new Handler() {
         public void handleMessage(Message msg) {
        	super.handleMessage(msg);
        	if ( p >= 100 ) {
        		pDialog.dismiss();
        		TextView output = (TextView) findViewById(R.id.lblOutput);
 	            output.setText("�U���w����....");
        	}	
        	else {
        		p++;
        		pDialog.incrementProgressBy(1);
        		pHandler.sendEmptyMessageDelayed(0,50);
        	}
          }        	
       };
    }
    @Override
    protected Dialog onCreateDialog(int id) {
       switch (id) {
    	case 0: // �Ǧ^AlertDialog��ܤ��
    	   return new AlertDialog.Builder(this)
    		.setTitle("�ФĿ�ﶵ?")
    		.setPositiveButton("�T�w",
    	     new DialogInterface.OnClickListener() { 
    	        public void onClick(DialogInterface  
    	                     dialoginterface, int i) {    	                  
    	           String msg = "";
    	           for (int index = 0; index < items.length; index++) {
    	           	  if (itemsChecked[index])
    	                msg += items[index] + "\n";        	   
    	           }
    	           TextView output = (TextView) findViewById(R.id.lblOutput);
    	           output.setText(msg);
    	        } 
    	     }) 
    	    .setNegativeButton("����", null) 
    	    .setMultiChoiceItems(items,itemsChecked,
    	     new DialogInterface.OnMultiChoiceClickListener() {
			    public void onClick(DialogInterface dialog, int which, boolean isChecked) {
				   Toast.makeText(Ch7_3_1Activity.this, 
					items[which] + (isChecked ? " �Ŀ�": "�S���Ŀ�"),
		      	    Toast.LENGTH_SHORT).show();   	 
				}
			 })
    	    .create();
    	case 1: // �Ǧ^ProgressDialog��ܤ��
    		pDialog = new ProgressDialog(this);
    		pDialog.setTitle("�U���ɮ�...");
    		pDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
    		pDialog.setButton(DialogInterface.BUTTON_POSITIVE, "����" ,
    		 new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
			 	  Toast.makeText(Ch7_3_1Activity.this, 
					"���äU����ܤ��...",
				    Toast.LENGTH_SHORT).show();   	 
				}
			 });
			pDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "����" ,
			 new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
				  Toast.makeText(Ch7_3_1Activity.this, 
					"�����U��...",
				    Toast.LENGTH_SHORT).show();   	 
				}
			 });
    		return pDialog;
       }
       return null;
    }
    // button2�ƥ�B�z�{��
    public void button2_Click(View view) {  
       TextView output = (TextView) findViewById(R.id.lblOutput);
       output.setText("");
       showDialog(1); // ��ܹ�ܤ��  
       p = 0;   // ���]
       pDialog.setProgress(0);
       pHandler.sendEmptyMessage(0);
    }
    // button1�ƥ�B�z�{��
    public void button1_Click(View view) {    	
       showDialog(0); // ��ܹ�ܤ��        
    }   
}