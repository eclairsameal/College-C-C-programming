package android_Examples.ch07.ch7_4_1;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class Ch7_4_1Activity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        int score = 20;
        String resultMsgFmt = getResources().getString(R.string.resultMsg);
        String resultMsg = String.format(resultMsgFmt, score);
        TextView result = (TextView) findViewById(R.id.lblResult);
        result.setText(resultMsg);
        String name = "���|�w";
        String device = "���O�q��";
        String myMsgFmt = getResources().getString(R.string.myMsg);
        String myMsg = String.format(myMsgFmt, name, device);
        TextView my = (TextView) findViewById(R.id.lblMy);
        my.setText(myMsg);
    }
}