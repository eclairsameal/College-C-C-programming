package android_Examples.ch07.ch7_5_2;

import android.app.Activity;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

public class Ch7_5_2Activity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        TextView label = (TextView) findViewById(R.id.label1);
        Animation anim = AnimationUtils.loadAnimation(this, R.anim.anim_text);
        label.startAnimation(anim);  // �Ұʰʵe
    }
	@Override
	protected void onPause() {
		super.onPause();
		TextView label = (TextView) findViewById(R.id.label1);
		label.clearAnimation(); // �M���ʵe
	}
}