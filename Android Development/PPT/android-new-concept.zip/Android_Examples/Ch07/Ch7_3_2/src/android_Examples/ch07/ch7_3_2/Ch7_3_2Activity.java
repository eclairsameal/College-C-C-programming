package android_Examples.ch07.ch7_3_2;

import java.util.Calendar;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;

public class Ch7_3_2Activity extends Activity {
    static final int DATE_DIALOG_ID = 0;
    static final int TIME_DIALOG_ID = 1;
    Calendar dt = Calendar.getInstance();
    @Override
    public void onCreate(Bundle savedInstanceState) {
       super.onCreate(savedInstanceState);
       setContentView(R.layout.main);
    }
    protected Dialog onCreateDialog(int id) {
       switch (id) {
       case DATE_DIALOG_ID: // �Ǧ^DatePickerDialog��ܤ��
    	  DatePickerDialog dDialog = new DatePickerDialog(this,
    	     new DatePickerDialog.OnDateSetListener() {
			 public void onDateSet(DatePicker view, int year, 
				  int monthOfYear,	int dayOfMonth) {						
	    	   TextView output = (TextView) findViewById(R.id.lblOutput);
	     	   output.setText(Integer.toString(year) + "/" +
			                  Integer.toString(monthOfYear+1) + "/" +
   	           		       Integer.toString(dayOfMonth)); 
		   	 }							   	
		  }, dt.get(Calendar.YEAR),
			 dt.get(Calendar.MONTH),
			 dt.get(Calendar.DAY_OF_MONTH));
    	  return dDialog;
       case TIME_DIALOG_ID: // �Ǧ^TimePickerDialog��ܤ��
    	  TimePickerDialog tDialog = new TimePickerDialog(this,
    		 new TimePickerDialog.OnTimeSetListener() {
    		 @Override
    	  	 public void onTimeSet(TimePicker view,
    	  			 int hourOfDay, int minute) {
    		   TextView output = (TextView) findViewById(R.id.lblOutput);
	     	   output.setText(Integer.toString(hourOfDay) + ":" +
	     	    		      Integer.toString(minute));     					
             }
    	  }, dt.get(Calendar.HOUR),dt.get(Calendar.MINUTE),true);
     	  return tDialog;
       }
       return null;
    }
    // button1�ƥ�B�z�{��
    public void button1_Click(View view) { 
        showDialog(DATE_DIALOG_ID); // ��ܹ�ܤ��        
    }
    // button2�ƥ�B�z�{��
    public void button2_Click(View view) { 
        showDialog(TIME_DIALOG_ID); // ��ܹ�ܤ��        
    }
}