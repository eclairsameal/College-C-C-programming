package android_Examples.ch10.ch10_2_1;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Ch10_2_1Activity extends Activity {
    private static final int READ_BLOCK_SIZE = 100;
    private String fname = "note.txt";
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    // Button���󪺨ƥ�B�z
    public void btnSave_Click(View view) {
    	EditText input = (EditText) findViewById(R.id.txtInput);
    	String str = input.getText().toString();
    	try {
    		// �}�Ҽg�J�ɮ�
    		FileOutputStream out = openFileOutput(fname,MODE_PRIVATE);
    		OutputStreamWriter sw = new OutputStreamWriter(out);
    		sw.write(str);  // �N�r��g�J��y
    		sw.flush();     // ��X��y���
    		sw.close();     // ������y
    		Toast.makeText(this, "���\�g�J�ɮ�...", 
    				Toast.LENGTH_SHORT).show();
    		input.setText("");  // �M��EditText���󪺤��e   		
    	}
    	catch (IOException ex) {
    		ex.printStackTrace();
    	}
    }
    public void btnRead_Click(View view) {
    	try {
    		// �}��Ū���ɮ�
    		FileInputStream in = openFileInput(fname);
    		InputStreamReader sr = new InputStreamReader(in);
    		char[] buffer = new char[READ_BLOCK_SIZE];
    		String str = "";
    		int count;
    		// Ū���ɮפ��e
            while ((count = sr.read(buffer)) > 0) {
            	String s = String.copyValueOf(buffer,0, count);
            	str += s;
            	buffer = new char[READ_BLOCK_SIZE];
            }
    		sr.close();     // ������y
    		Toast.makeText(this, "���\Ū���ɮ�...", 
    				Toast.LENGTH_SHORT).show();
    	    TextView output = (TextView) findViewById(R.id.lblOutput);
    	    output.setText("Ū�����e:\n" + str);
    	}
    	catch (IOException ex) {
    		ex.printStackTrace();
    	} 
    }
}