package android_Examples.ch10.ch10_1_2;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;

public class Activity2 extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// ���oSharedPreferences���]�w���
		SharedPreferences prefs;
		prefs = getSharedPreferences("MyPref", MODE_PRIVATE);
		String str = prefs.getString("AMOUNT", "1000");
    	Toast.makeText(this, "Activity2: " + str, 
				Toast.LENGTH_SHORT).show();
	}
}
