package android_Examples.ch10.ch10_1_2;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class Ch10_1_2Activity extends Activity {
	private SharedPreferences prefs;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);        
        prefs = getSharedPreferences("MyPref", MODE_PRIVATE);
        // ���oEditor����
     	SharedPreferences.Editor prefEdit = prefs.edit();
     	// �s�J���n�]�w��Ʀ�Editor����
     	prefEdit.putString("AMOUNT", "500");
   		prefEdit.commit(); // �T�{�g�J�ɮ�	
    }
    // Button���󪺨ƥ�B�z
    public void btn1_Click(View view) {
    	// ���oSharedPreferences���]�w���
    	String str = prefs.getString("AMOUNT", "1000");
    	Toast.makeText(this, "Ch10_1_2Activity: " + str, 
				Toast.LENGTH_SHORT).show();
        Intent i = new Intent(this, Activity2.class);
        startActivity(i);    	
    }
}