package android_Examples.ch10.ch10_1_1;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Ch10_1_1Activity extends Activity {
	private static final String PREF_AMOUNT = "Amount";
	private static final String PREF_RATE = "Rate";
	private EditText txtAmount, txtRate;
	private SharedPreferences prefs;	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        // ���oEditText����
        txtAmount = (EditText) findViewById(R.id.txtAmount);
        txtRate = (EditText) findViewById(R.id.txtRate);
        // ���oSharedPreferences����
        prefs =	getPreferences(MODE_PRIVATE);        
    }
    @Override
	protected void onResume() {
		super.onResume();
		// ���o���n�]�w���
		String amount = prefs.getString(PREF_AMOUNT, "10000");
        txtAmount.setText(amount);
        float rate = prefs.getFloat(PREF_RATE, 28.9F);
        txtRate.setText(String.valueOf(rate));
	}
	@Override
	protected void onPause() {
		super.onPause();
		// ���oEditor����
		SharedPreferences.Editor prefEdit = prefs.edit();
		// �s�J���n�]�w��Ʀ�Editor����
		prefEdit.putString(PREF_AMOUNT, txtAmount.getText().toString());
		float rate;
		rate = (float) Double.parseDouble(txtRate.getText().toString());
		prefEdit.putFloat(PREF_RATE, rate);
		prefEdit.commit(); // �T�{�g�J�ɮ�		
	}
    // Button���󪺨ƥ�B�z
    public void btn1_Click(View view) {
    	double amount, rate, result;
    	amount = Double.parseDouble(txtAmount.getText().toString());
    	rate = Double.parseDouble(txtRate.getText().toString());
    	// �p��I�����B
    	result = amount / rate;
    	// ��ܧI�����B
    	TextView output = (TextView) findViewById(R.id.lblOutput);
    	output.setText("����: " + Double.toString(result));    	
    }
}