package android_Examples.ch10.ch10_1_3;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.TextView;

public class Ch10_1_3Activity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        // ���J���n�]�w�w�]��
        PreferenceManager.setDefaultValues(this,R.xml.preferences,false);
    }
    // �ƥ�B�z�{��
    public void btn1_Click(View view) {
    	startActivity(new Intent(this, Preferences.class));
    }
    public void btn2_Click(View view) {
    	// ���oSharedPreferences����
    	SharedPreferences settings = 
    			PreferenceManager.getDefaultSharedPreferences(this);
        // ���o�]�w��
    	String username = settings.getString("username", "");
        String password = settings.getString("password", "");
        boolean isMorePrefs = settings.getBoolean("more_pref", false);
        String color = settings.getString("color_pref", "");
        TextView output = (TextView)
                findViewById(R.id.lblOutput);
        output.setText("�ϥΪ̦W��: "+ username +
        		       "\n�ϥΪ̱K�X: " + password +
        		       "\n�}�ҧ�h�]�w: " + isMorePrefs +
        		       "\n�߷R����m: " + color);
    }
}