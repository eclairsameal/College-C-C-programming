package android_Examples.ch09.ch9_4_2;

import android.app.Activity;
import android.app.SearchManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Toast;

public class Ch9_4_2Activity extends Activity {
	private static final int GET_CONTACT = 1;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    // �ƥ�B�z�{��
    public void btn1_Click(View view) {
    	Intent i = new Intent(Intent.ACTION_VIEW,
    			 Uri.parse("http://www.google.com.tw"));
    	startActivity(i);    	
    }
    public void btn2_Click(View view) {
    	Intent i = new Intent(Intent.ACTION_VIEW,
		        Uri.parse("geo:25.04692437135412,121.5161783959678"));
        startActivity(i);  
    }
    public void btn3_Click(View view) {
    	Intent i = new Intent(Intent.ACTION_DIAL,
		        Uri.parse("tel:+1234567"));
        startActivity(i);  
    }
    public void btn4_Click(View view) {
    	Intent i = new Intent(Intent.ACTION_PICK);
		i.setType(ContactsContract.Contacts.CONTENT_TYPE);
        startActivityForResult(i, GET_CONTACT);  
    }
    public void btn5_Click(View view) {
    	Intent i = new Intent(Intent.ACTION_WEB_SEARCH);
    	i.putExtra(SearchManager.QUERY, "Android");
        startActivity(i);  
    }
    public void btn6_Click(View view) {
    	Intent i = new Intent(Intent.ACTION_SENDTO,
		        Uri.parse("mailto:hueyan@ms2.hinet.net"));
        startActivity(i); 
    }
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == GET_CONTACT) {
			if (resultCode == RESULT_OK) {
				String uri = data.getData().toString();
				Toast.makeText(this, uri, Toast.LENGTH_SHORT).show();
				Intent i = new Intent(Intent.ACTION_VIEW,
    			        Uri.parse(uri));
    	        startActivity(i);    	
			}
		}
	}
}