package android_Examples.ch09.ch9_2_1;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Ch9_2_1Activity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    public void button1_Click(View view) {
    	// ��k�@
    	Intent myIntent =    			
    		new Intent(this, SecondActivity.class);
    	// ��k�G		
        // Intent myIntent = new Intent();
    	// myIntent.setClass(this, SecondActivity.class);
    	startActivity(myIntent);
    }
}