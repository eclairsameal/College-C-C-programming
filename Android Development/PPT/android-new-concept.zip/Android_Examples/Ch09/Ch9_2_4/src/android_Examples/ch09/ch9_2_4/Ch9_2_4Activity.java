package android_Examples.ch09.ch9_2_4;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Ch9_2_4Activity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    // �ƥ�B�z�{��
    public void btn1_Click(View view) {
    	startActivity(new Intent("ch09.ch9_2_4.PREFERENCE"));
    }
}