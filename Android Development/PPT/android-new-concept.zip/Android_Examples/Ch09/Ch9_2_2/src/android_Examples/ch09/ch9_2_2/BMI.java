package android_Examples.ch09.ch9_2_2;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class BMI extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.bmi);
		displayBMI();
	}
	// ���BMI��
	private void displayBMI() {
		double height, weight, bmi;
		// ���o�ǻ������
		Bundle bundle = this.getIntent().getExtras();
		if (bundle != null) {
		  height = Double.parseDouble(bundle.getString("HEIGHT"));
		  weight = Double.parseDouble(bundle.getString("WEIGHT"));
		  // �p��BMI
		  height = height / 100.00;
		  bmi = weight / (height * height);
		  // ���BMI
		  TextView output = (TextView) findViewById(R.id.lblOutput);
		  output.setText("BMI��: " + Double.toString(bmi));		  
		}
	}
	// btn2���ƥ�B�z
	public void btn2_Click(View view) {
		finish(); // ��������
	}
}
