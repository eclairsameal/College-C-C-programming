package android_Examples.ch09.ch9_2_5;

import android.app.Activity;
import android.os.Bundle;

public class Activity2 extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity2);
	}
}
