package android_Examples.ch09.ch9_5;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Ch9_5Activity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        Button btn = (Button) findViewById(R.id.btn1);
        // ���U��ť�̪���
        btn.setOnClickListener(listener);        
    }
    // �إ߶�ť�̪���
    View.OnClickListener listener = new View.OnClickListener() {
    	public void onClick(View v) {
    		// ���oEditText����
    		EditText height = (EditText) findViewById(R.id.txtHeight);
    		EditText weight = (EditText) findViewById(R.id.txtWeight);
    		// �إ�Intent����
    		Intent myIntent = new Intent();
    		myIntent.setClass(Ch9_5Activity.this, BMI.class);
    		// �إ߶ǻ���ƪ�Bundle����
    		Bundle bundle = new Bundle(); 
    		bundle.putString("HEIGHT", height.getText().toString());
    		bundle.putString("WEIGHT", weight.getText().toString());
    		myIntent.putExtras(bundle);  // �[�W���
    		startActivity(myIntent);     // �Ұʬ���    		 		
    	}
    };
}