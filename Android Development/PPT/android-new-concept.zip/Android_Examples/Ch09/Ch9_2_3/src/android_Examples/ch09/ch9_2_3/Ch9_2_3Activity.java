package android_Examples.ch09.ch9_2_3;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Ch9_2_3Activity extends Activity {
	private static final int SET_HOROSCOPE = 1;
	private EditText txtMonth;
	private EditText txtDay;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        txtMonth = (EditText) findViewById(R.id.txtMonth);
        txtMonth.setText("1");
        txtDay = (EditText) findViewById(R.id.txtDay);
        txtDay.setText("1");
    }
    // �ƥ�B�z�{��
    public void btn1_Click(View view) {
    	int month, day;
    	month =	Integer.parseInt(txtMonth.getText().toString());
    	day = Integer.parseInt(txtDay.getText().toString());
    	if ((month < 1 || month > 12) ||
    		(day < 1 || day > 31)) {
    		Toast.makeText(Ch9_2_3Activity.this,"��ƽd����~!",
    			  Toast.LENGTH_SHORT).show();
    		return;
    	}
    	// �إ�Intent����
    	Intent myIntent = new Intent(this, Horoscope.class);
    	// �[�J�ǻ����
		myIntent.putExtra("MONTH", month);
		myIntent.putExtra("DAY", day);
		// �Ұʬ��ʥB���^�Ǹ��
    	startActivityForResult(myIntent, SET_HOROSCOPE);
    }
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		switch(requestCode) {
		case SET_HOROSCOPE:
		  if (resultCode == RESULT_OK) {
		    Bundle bundle = data.getExtras();		
		    TextView output = (TextView) findViewById(R.id.lblResult);
		    output.setText("�ͤ�: "+ txtMonth.getText() + "��" +
		           txtDay.getText() + "��\n�P�y: " + 
		 	       bundle.getString("HOROSCOPE"));
		  }
		  break;
		}
	}
}