package android_Examples.ch03.ch3_5_2;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Ch3_5_2Activity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    // Button���󪺨ƥ�B�z
    public void button1_Click(View view) {
    	TextView output = (TextView) findViewById(R.id.txtOutput);
    	String str = "";
    	int total = 0;
    	str = "for�p�ưj��\n";
    	for ( int i = 1; i <= 10; i++ ) {
    	   str +="|" + i;
    	   total += i;
    	}
    	str +="|=" + total;
    	str += "\n�e����while�j��ԭz\n";
    	int level = 1;
    	int n = 1;
    	while ( level <= 5 ) {
    	   n *= level;
    	   str += level + "!=" + n + "\n";
    	   level++;
    	}
    	str += "�����do/while�j��ԭz\n";
    	double f;
    	double c = 50;
    	double upper = 100;
    	int step = 10;
    	do {
    		f = (9.0 * c) / 5.0 + 32.0;
    		str += c + "\t" + f + "\n";
    		c += step;
    	} while ( c <= upper);
    	str += "break���O���_�j��\n";
    	int i = 1;
    	int sum = 0;
    	do {
    	   str += "|" + i;
    	   sum += i;
    	   i++;
    	   if ( i > 10 ) break;
    	} while ( true );
    	str +="|=" + sum;
    	str += "\ncontinue���O�~��j��\n";
    	int sumOdd = 0;
    	for (int num = 1; num <= 10; num++ ) {
    	   if ( (num % 2) == 0 ) continue;
    	   str += "|" + num;
    	   sumOdd += num;
    	}
    	str +="|=" + sumOdd;    	
    	output.setText(str);
    }
}