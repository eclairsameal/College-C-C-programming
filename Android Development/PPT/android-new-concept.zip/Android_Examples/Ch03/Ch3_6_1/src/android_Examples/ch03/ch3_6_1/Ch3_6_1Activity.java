package android_Examples.ch03.ch3_6_1;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Ch3_6_1Activity extends Activity {
    private static String str="";
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    // ���O��k
    private static void printTriangle() {    	
        int i, j;
        for ( i = 1; i <= 5; i++) {
          for ( j = 1; j <= i; j++)
             str += "*";
          str += "\n";
       }
    }
    // Button���󪺨ƥ�B�z
    public void button1_Click(View view) {
    	printTriangle();
    	TextView output = (TextView) findViewById(R.id.txtOutput);
    	output.setText(str);
    }	
}