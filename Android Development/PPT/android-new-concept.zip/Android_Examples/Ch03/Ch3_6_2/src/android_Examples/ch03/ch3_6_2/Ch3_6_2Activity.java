package android_Examples.ch03.ch3_6_2;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Ch3_6_2Activity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    // ���O��k: �p��n �[�� n
    static int sumN2N(int begin, int end) {
   	    int i;
   	    int total = 0;
   	    for ( i = begin; i <= end; i++ )
   	      total += i;
   	    return total;
    }
    // Button���󪺨ƥ�B�z
    public void button1_Click(View view) {
    	TextView output = (TextView) findViewById(R.id.txtOutput);
    	int total, total1, total2;
    	total = sumN2N(5, 15);  // �I�s���O��k
    	total1 = sumN2N(1, 50);
    	total2 = sumN2N(1, 100);
    	output.setText("�q5�[��15= " + total + 
    			       "\n�q1�[��50= " + total1 +
    			       "\n�q1�[��100= " + total2);
    }
}