package android_Examples.ch03.ch3_7_1;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Ch3_7_1Activity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    // Button���󪺨ƥ�B�z
    public void button1_Click(View view) {
    	TextView output = (TextView) findViewById(R.id.txtOutput);
    	String str = "";
    	int i, sum = 0;  // �ܼƫŧi
    	double average, total = 0.0;
    	// �إ�int�}�C 
    	int[] temp;  // �ŧi�}�C�ܼ� 
    	int[] tips = {150, 200, 300};
    	// �إ�double�}�C
    	double[] sales = new double[4];
    	sales[0] = 145.6;  // �Ĥ@�u
    	sales[1] = 178.9;  // �ĤG�u
    	sales[2] = 197.3;  // �ĤT�u
    	sales[3] = 156.7;  // �ĥ|�u
    	temp = tips;
    	// �ϥΰj����ܰ}�C�ȩM�p���`�M
    	for ( i=0; i < tips.length; i++ ) {
    	   sum += temp[i];
    	   str += "| " + temp[i];
    	}
    	str += "\n�p�O�`�p: " + sum + "\n";
    	// �ϥΰj����ܰ}�C�ȩM�p�⥭��
    	for ( i=0; i < sales.length; i++) {
    	   total += sales[i];
    	   str += "| " + sales[i];
    	}
    	str += "\n�~�Z�`�M: " + total;
    	average = total/(double)sales.length;
    	str += "\n�����~�Z: " + average;
    	output.setText(str);    	
    }
}