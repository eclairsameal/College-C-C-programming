<?php

/**************************************************************************/
/*                                                                        */
/* lLENGUA CATALANA By:                                                   */
/*          -=^OutOfOrder^=-                                              */
/*                                                                        */
/**************************************************************************/


define("_SEND","Enviar");
define("_YOURNAME","El teu nom");
define("_MESSAGE","Missatge");
define("_YOUREMAIL","La teva compta de Correu Electr�nic");
define("_FEEDBACKNOTE","S�n benvinguts tots els comentaris i sugger�ncies sobre aquesta p�gina, a m�s a m�s de ser una font molt preciosa d'informaci� per a nosaltres. Gr�cies!");
define("_FEEDBACKTITLE","Formulari de Feedback");
define("_FEEDBACK","Feedback");
define("_FBENTERNAME","ERROR: Si us plau introdueix el teu nom!");
define("_FBENTEREMAIL","ERROR: Si us plau introdueix el teu compte de Correu Electr�nic!");
define("_FBENTERMESSAGE","ERROR: Si us plau escriu el teu missatge!");
define("_SENDEREMAIL","El teu compte de Correu Electr�nic");
define("_SENDERNAME","El teu Nom");
define("_FBMAILSENT","El Missatge s'ha enviado exitosament!");
define("_FBTHANKSFORCONTACT","Gr�cies per contactar amb nosaltres!");

?>