<?php

/**************************************************************************/
/* PHP-NUKE: Advanced Content Management System                           */
/* ============================================                           */
/*                                                                        */
/* Php-Nuke'nin s�rekli geli�mesine ba�l� olarak eski T�rk�e dil dosyalar�*/
/* g�ncelli�ini yitirdi�i i�in "HighLAndeR" taraf�ndan "MaXCoDeR"in       */
/* yapm�� oldu�u �eviriler g�ncelle�tirilip yeni �eviriler eklenmi�tir... */
/*                                                                        */
/* NOT: Yard�mlar� i�in Gurol400(gurol400@propc.org)'e te�ekk�rler.       */
/*                                                                        */
/* T�rk�e �evirmeni: HighLAndeR                                           */
/* Email: highlander@propc.org ICQ#: 110930777 	URL: http://www.propc.org */
/*                                                                        */
/* T�rk�e �evirmeni: Selim "MaXCoDeR" �umlu                               */
/* Mail:webmaster@pcnet.com.tr ICQ:19648424 URL: http://www.turknuke.com  */
/**************************************************************************/

define("_SEND","G�nder");
define("_YOURNAME","�sminiz");
define("_MESSAGE","Mesaj");
define("_YOUREMAIL","Email'iniz");
define("_FEEDBACKNOTE","Bu site hakk�nda t�m yorumlar�n�z ve �nerileriniz bizim i�in de�erlidir. Te�ekk�rler!");
define("_FEEDBACKTITLE","�leti�im Formu");
define("_FEEDBACK","�leti�im");
define("_FBENTERNAME","HATA: L�tfen isminizi girin!");
define("_FBENTEREMAIL","HATA: L�tfen email adresinizi girin!");
define("_FBENTERMESSAGE","HATA: L�tfen bir mesaj girin!");
define("_SENDEREMAIL","G�nderenin Emaili");
define("_SENDERNAME","G�nderenin �smi");
define("_FBMAILSENT","Mail g�nderildi!");
define("_FBTHANKSFORCONTACT","Bizimle ileti�im kurdu�unuz i�in te�ekk�rler.");

?>