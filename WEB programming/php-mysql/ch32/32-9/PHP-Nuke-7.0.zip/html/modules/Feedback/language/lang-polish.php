<?php

/**************************************************************************/
/* PHP-NUKE: Advanced Content Management System                           */
/* ============================================                           */
/*                                                                        */
/* This is the language module with all the system messages               */
/*                                                                        */
/* If you made a translation, please go to the site and send to me        */
/* the translated file. Please keep the original text order by modules,   */
/* and just one message per line, also double check your translation!     */
/*                                                                        */
/* You need to change the second quoted phrase, not the capital one!      */
/*                                                                        */
/* If you need to use double quotes (") remember to add a backslash (\),  */
/* so your entry will look like: This is \"double quoted\" text.          */
/* And, if you use HTML code, please double check it.                     */
/*                                                                        */
/* Polish translation by Nordavind�(Bolo) (http://forum.phpnuke.org.pl)   */
/*                                                                        */
/**************************************************************************/

define("_SEND","Wy�lij");
define("_YOURNAME","Twoje imi� i nazwisko");
define("_MESSAGE","Wiadomo��");
define("_YOUREMAIL","Tw�j adres e-mail");
define("_FEEDBACKNOTE","Wszystkie sugestie i komentarze dotycz�ce tej strony s� mile widziane i s� cennym �r�d�em informacji dla nas!");
define("_FEEDBACKTITLE","Formularz kontaktowy");
define("_FEEDBACK","Kontakt");
define("_FBENTERNAME","B��D: Wpisz sw�j nick!");
define("_FBENTEREMAIL","B��D: Podaj sw�j adres e-mail!");
define("_FBENTERMESSAGE","B��D: Wpisz wiadomo��!");
define("_SENDEREMAIL","Imi� nadawcy");
define("_SENDERNAME","Nick nadawcy");
define("_FBMAILSENT","E-mail zosta� wys�any!");
define("_FBTHANKSFORCONTACT","Dzi�kujemy za po�wi�cenie czasu i wys�anie formularza");

?>