<?php

/**************************************************************************/
/* PHP-NUKE: Advanced Content Management System                           */
/* ============================================                           */
/* Dato: 6. september 2002                                                */
/* PHP-NUKE Version: 6.0                                                  */
/* Denne sprog-fil er blevet oversat til dansk fra engelsk af:            */
/*                                                                        */
/* Navn:	Christian Botved Poulsen                                      */
/* E-mail:	Christian_B_P@Get2net.dk                                      */
/* ICQ:	155265588                                                     */
/* Webside:	www.Sjove-Film.dk - HitsMaskinen.dk - FilmCentralen.dk        */
/*                                                                        */
/* Hvis de finder fejl m� og skal de sende en e-mail eller icq til mig!   */
/**************************************************************************/


define("_SEND","Send");
define("_YOURNAME","Dit navn");
define("_MESSAGE","Besked");
define("_YOUREMAIL","Din e-mailadresse");
define("_FEEDBACKNOTE","Alle kommentarer og foreslag omkring dette website er mere end velkomne. Mange tak!");
define("_FEEDBACKTITLE","Feedback formular");
define("_FEEDBACK","Feedback");
define("_FBENTERNAME","Fejl: V�r venlig at indtaste deres navn!");
define("_FBENTEREMAIL","Fejl: V�r venlig at indtaste deres e-mail!");
define("_FBENTERMESSAGE","Fejl: V�r venlig at indtaste en besked!");
define("_SENDEREMAIL","Afstenders e-mail");
define("_SENDERNAME","Afstenders navn");
define("_FBMAILSENT","E-mailen er sendt!");
define("_FBTHANKSFORCONTACT","Tak for at kontakte os!");

?>