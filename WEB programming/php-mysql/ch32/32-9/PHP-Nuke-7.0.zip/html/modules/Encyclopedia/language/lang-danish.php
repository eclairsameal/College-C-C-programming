<?php

/**************************************************************************/
/* PHP-NUKE: Advanced Content Management System                           */
/* ============================================                           */
/* Dato: 6. september 2002                                                */
/* PHP-NUKE Version: 6.0                                                  */
/* Denne sprog-fil er blevet oversat til dansk fra engelsk af:            */
/*                                                                        */
/* Navn:	Christian Botved Poulsen                                      */
/* E-mail:	Christian_B_P@Get2net.dk                                      */
/* ICQ:	155265588                                                     */
/* Webside:	www.Sjove-Film.dk - HitsMaskinen.dk - FilmCentralen.dk        */
/*                                                                        */
/* Hvis de finder fejl m� og skal de sende en e-mail eller icq til mig!   */
/**************************************************************************/

define("_PREVIOUS","Forrige side");
define("_NEXT","N�ste side");
define("_SEARCHRESULTS","S�geresultater");
define("_PAGE","Side");
define("_RETURNTO","Tilbage til");
define("_DEACTIVATE","Deaktiver");
define("_ACTIVATE","Aktiver");
define("_ENCYCLOPEDIA","Leksikon");
define("_NOCONTENTFORLETTER","Desv�rre, der er intet data vedr. det valgte bokstav");
define("_ENCYSELECTLETTER","V�r venlig at v�lge et bokstav fra den f�lgende liste:");
define("_COPYRIGHT","Copyright");
define("_YOURADMINENCY","De er administrator, dette leksikon er ikke aktiveret!");
define("_ENCYNOTACTIVE","Desv�rre, dette leksikon er ikke aktiveret ligenu.");
define("_AVAILABLEENCYLIST","Liste over mulige leksikon/'er i ");
define("_YOURADMININACTIVELIST","De er administrator: f�lgende er en liste over deaktiverede leksikon/'er:");
define("_NORESULTSTEXT","Intet resultater i dette opslags tekst...");
define("_NORESULTSTITLE","Intet resultat i dette opslags titel...");
define("_SEARCHRESULTSFOR","S�gningsresultater for:");
define("_SEARCHNOTCOMPLETE","S�gningen er ikke f�rdig. Pr�v igen.");
define("_RESULTSINTERMTITLE","Resultater i opslagets titel:");
define("_RESULTSINTERMTEXT","Resultater i opslagets tekst:");

?>