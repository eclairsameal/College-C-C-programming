<?php

/**************************************************************************/
/*                                                                        */
/* lLENGUA CATALANA By:                                                   */
/*          -=^OutOfOrder^=-                                              */
/*                                                                        */
/**************************************************************************/


define("_PREVIOUS","P�gina Anterior");
define("_NEXT","P�gina Seg�ent");
define("_SEARCHRESULTS","Resultats de la B�squeda");
define("_PAGE","p�gina(es) ");
define("_RETURNTO","Tornar a");
define("_DEACTIVATE","Desactivar");
define("_ACTIVATE","Activar");
define("_ENCYCLOPEDIA","Enciclopedia");
define("_NOCONTENTFORLETTER","Perdona, no existeix cap contingut per la lletra");
define("_ENCYSELECTLETTER","Si us plau selecciona una lletra de la sig�ent llista per a consultar els termes:");
define("_COPYRIGHT","Copyright");
define("_YOURADMINENCY","Ets Administrador, aquesta enciclopedia no est� activada!");
define("_ENCYNOTACTIVE","Perdona, aquesta enciclopedia no est� activada amb aquests moments.");
define("_AVAILABLEENCYLIST","Lista de les Enciclopedies disponibles a");
define("_YOURADMININACTIVELIST","Ets Administrador: Llista de las Enciclopedies Inactives:");
define("_NORESULTSTEXT","No hi han Resultats al Text dels Termes...");
define("_NORESULTSTITLE","No hi han Resultats al T�tol dels Termes...");
define("_SEARCHRESULTSFOR","Resultats de la Recerca de:");
define("_SEARCHNOTCOMPLETE","Les opcions de la recerca no est�n completes. Si us palau prova-ho de nou.");
define("_RESULTSINTERMTITLE","Resultats al t�tol dels termes:");
define("_RESULTSINTERMTEXT","Resultats al text dels termes:");

?>