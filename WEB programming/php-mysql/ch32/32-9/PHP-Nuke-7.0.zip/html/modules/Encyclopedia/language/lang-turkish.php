<?php

/**************************************************************************/
/* PHP-NUKE: Advanced Content Management System                           */
/* ============================================                           */
/*                                                                        */
/* Php-Nuke'nin s�rekli geli�mesine ba�l� olarak eski T�rk�e dil dosyalar�*/
/* g�ncelli�ini yitirdi�i i�in "HighLAndeR" taraf�ndan "MaXCoDeR"in       */
/* yapm�� oldu�u �eviriler g�ncelle�tirilip yeni �eviriler eklenmi�tir... */
/*                                                                        */
/* NOT: Yard�mlar� i�in Gurol400(gurol400@propc.org)'e te�ekk�rler.       */
/*                                                                        */
/* T�rk�e �evirmeni: HighLAndeR                                           */
/* Email: highlander@propc.org ICQ#: 110930777 	URL: http://www.propc.org */
/*                                                                        */
/* T�rk�e �evirmeni: Selim "MaXCoDeR" �umlu                               */
/* Mail:webmaster@pcnet.com.tr ICQ:19648424 URL: http://www.turknuke.com  */
/**************************************************************************/

define("_PREVIOUS","�nceki Sayfa");
define("_NEXT","Sonraki Sayfa");
define("_SEARCHRESULTS","Arama Sonu�lar�");
define("_PAGE","Sayfa");
define("_RETURNTO","Geri D�n:");
define("_DEACTIVATE","Pasifle�tir");
define("_ACTIVATE","Etkinle�tir");
define("_ENCYCLOPEDIA","Ansiklopedi");
define("_NOCONTENTFORLETTER","�zg�n�m, bu harf i�in i�erik mevcut de�il");
define("_ENCYSELECTLETTER","Terimleri g�rmek i�in l�tfen listeden bir harf se�in:");
define("_COPYRIGHT","Telif Hakk�");
define("_YOURADMINENCY","Y�neticisiniz, bu ansiklopedi aktif de�il!");
define("_ENCYNOTACTIVE","�zg�n�m, bu ansiklopedi �u an aktif de�il.");
define("_AVAILABLEENCYLIST","Ansiklopedi Listesi:");
define("_YOURADMININACTIVELIST","Y�neticisiniz: pasif ansiklopedilerin listesi a�a��dad�r:");
define("_NORESULTSTEXT","Terim metninde sonu� bulunamad�...");
define("_NORESULTSTITLE","Terim ba�l���nda sonu� bulunamad�...");
define("_SEARCHRESULTSFOR","Arama Sonu�lar�:");
define("_SEARCHNOTCOMPLETE","Arama se�enekleri eksik. L�tfen tekrar deneyin.");
define("_RESULTSINTERMTITLE","Terim ba�l���nda sonu�lar:");
define("_RESULTSINTERMTEXT","Terim metninde sonu�lar:");

?>