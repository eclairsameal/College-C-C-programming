<?php

/**************************************************************************/
/*                                                                        */
/* lLENGUA CATALANA By:                                                   */
/*          -=^OutOfOrder^=-                                              */
/*                                                                        */
/**************************************************************************/


define("_PREVIOUS","P�gina Anterior");
define("_NEXT","P�gina Seg�ent");
define("_PAGE","p�gina(es) ");
define("_DEACTIVATE","Desactivar");
define("_ACTIVATE","Activar");
define("_PUBLISHEDON","Publicat a");
define("_PAGESLIST","Llista de P�gines");
define("_LISTOFCONTENT","Llista del Contingut a");
define("_YOURADMINLIST","Ets Administrador: Seguidament la llista de p�gines inactives:");
define("_COPYRIGHT","Copyright &copy; per");
define("_COPYRIGHT2","Derets Reservats.");
define("_CONTENTCATEGORIES","Categories de Contingut");
define("_NONCLASSCONT","Contingut no categoritzat");

?>