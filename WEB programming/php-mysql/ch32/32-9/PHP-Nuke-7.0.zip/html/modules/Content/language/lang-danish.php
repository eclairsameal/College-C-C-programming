<?php

/**************************************************************************/
/* PHP-NUKE: Advanced Content Management System                           */
/* ============================================                           */
/* Dato: 6. september 2002                                                */
/* PHP-NUKE Version: 6.0                                                  */
/* Denne sprog-fil er blevet oversat til dansk fra engelsk af:            */
/*                                                                        */
/* Navn:	Christian Botved Poulsen                                      */
/* E-mail:	Christian_B_P@Get2net.dk                                      */
/* ICQ:	155265588                                                     */
/* Webside:	www.Sjove-Film.dk - HitsMaskinen.dk - FilmCentralen.dk        */
/*                                                                        */
/* Hvis de finder fejl m� og skal de sende en e-mail eller icq til mig!   */
/**************************************************************************/

define("_PREVIOUS","Forrige side");
define("_NEXT","N�ste side");
define("_PAGE","Side");
define("_DEACTIVATE","Deaktiver");
define("_ACTIVATE","Aktiver");
define("_PUBLISHEDON","Udsendt den");
define("_PAGESLIST","Side liste");
define("_LISTOFCONTENT","Liste med muligt indhold i");
define("_YOURADMINLIST","De er administrator: f�lgende er listen over deaktiverede sider:");
define("_COPYRIGHT","Copyright &copy; by");
define("_COPYRIGHT2","All Right Reserved.");
define("_CONTENTCATEGORIES","Leddige kategorier");
define("_NONCLASSCONT","Ikke kategoriserede sider");

?>