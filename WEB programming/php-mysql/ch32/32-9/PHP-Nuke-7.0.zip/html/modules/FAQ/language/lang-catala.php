<?php

/**************************************************************************/
/*                                                                        */
/* lLENGUA CATALANA By:                                                   */
/*          -=^OutOfOrder^=-                                              */
/*                                                                        */
/**************************************************************************/


define("_CATEGORY","Categoria");
define("_CATEGORIES","Categories");
define("_FAQ2","FAQ (Preguntes Freq�ents)");
define("_BACKTOTOP","Tornar a l'inici");
define("_BACKTOFAQINDEX","Retorna a l'�ndex del FAQ ");
define("_MAIN","Principal");
define("_QUESTION","Pregunta");
define("_ANSWER","Resposta");

?>