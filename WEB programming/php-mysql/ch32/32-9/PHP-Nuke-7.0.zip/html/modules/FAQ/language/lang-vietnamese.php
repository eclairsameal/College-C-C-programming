<?php

/**************************************************************************/
/* PHP-NUKE: Advanced Content Management System                           */
/* ============================================                           */
/*                                                                        */
/* This is the language module with all the system messages               */
/*                                                                        */
/* If you made a translation, please go to the site and send to me        */
/* the translated file. Please keep the original text order by modules,   */
/* and just one message per line, also double check your translation!     */
/*                                                                        */
/* You need to change the second quoted phrase, not the capital one!      */
/*                                                                        */
/* If you need to use double quotes (") remember to add a backslash (\),  */
/* so your entry will look like: This is \"double quoted\" text.          */
/* And, if you use HTML code, please double check it.                     */
/**************************************************************************/

define("_CATEGORY","Danh m&#7909;c");
define("_CATEGORIES","Nhi&#7873;u danh m&#7909;c");
define("_FAQ2","FAQ (C�u Th&#432;&#7901;ng H&#7887;i)");
define("_BACKTOTOP","Tr&#7903; l&#7841;i &#273;&#7847;u");
define("_BACKTOFAQINDEX","Tr&#7903; l&#7841;i m&#7909;c l&#7909;c c&#7911;a C�u Th&#432;&#7901;ng H&#7887;i");
define("_MAIN","Ph&#7847;n Ch�nh");
define("_QUESTION","C�u h&#7887;i");
define("_ANSWER","Tr&#7843; l&#7901;i");

?>