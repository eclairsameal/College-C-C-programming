<?php

/**************************************************************************/
/* PHP-NUKE: Advanced Content Management System                           */
/* ============================================                           */
/* Dato: 6. september 2002                                                */
/* PHP-NUKE Version: 6.0                                                  */
/* Denne sprog-fil er blevet oversat til dansk fra engelsk af:            */
/*                                                                        */
/* Navn:	Christian Botved Poulsen                                      */
/* E-mail:	Christian_B_P@Get2net.dk                                      */
/* ICQ:	155265588                                                     */
/* Webside:	www.Sjove-Film.dk - HitsMaskinen.dk - FilmCentralen.dk        */
/*                                                                        */
/* Hvis de finder fejl m� og skal de sende en e-mail eller icq til mig!   */
/**************************************************************************/

define("_CATEGORY","Kategori");
define("_CATEGORIES","Kategorier");
define("_FAQ2","FAQ (Frequently Asked Questions)");
define("_BACKTOTOP","Til toppen");
define("_BACKTOFAQINDEX","Tilbage til oversigt over FAQ");
define("_MAIN","Hovedkategori");
define("_QUESTION","Sp�rgsm�l");
define("_ANSWER","Svar");

?>