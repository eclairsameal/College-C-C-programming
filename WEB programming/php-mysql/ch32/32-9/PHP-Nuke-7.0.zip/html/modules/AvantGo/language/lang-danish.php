<?php

/**************************************************************************/
/* PHP-NUKE: Advanced Content Management System                           */
/* ============================================                           */
/* Dato: 6. september 2002                                                */
/* PHP-NUKE Version: 6.0                                                  */
/* Denne sprog-fil er blevet oversat til dansk fra engelsk af:            */
/*                                                                        */
/* Navn:	Christian Botved Poulsen                                      */
/* E-mail:	Christian_B_P@Get2net.dk                                      */
/* ICQ:	155265588                                                     */
/* Webside:	www.Sjove-Film.dk - HitsMaskinen.dk - FilmCentralen.dk        */
/*                                                                        */
/* Hvis de finder fejl m� og skal de sende en e-mail eller icq til mig!   */
/**************************************************************************/

define("_PDATE","Dato:");
define("_PTOPIC","Emne:");
define("_COMESFROM","Denne artikel kommer fra");
define("_THEURL","Internetadressen til denne artikel er:");
define("_DATE","Dato");
define("_TITLE","Titel");

?>