<?php

/**************************************************************************/
/*                                                                        */
/* lLENGUA CATALANA By:                                                   */
/*          -=^OutOfOrder^=-                                              */
/*                                                                        */
/**************************************************************************/

define("_PDATE","Data");
define("_PTOPIC","Tema");
define("_COMESFROM","Aquest article ve de");
define("_THEURL","La direcci� d'aquesta noticia �s:");
define("_DATE","Data");
define("_TITLE","T�tol");

?>