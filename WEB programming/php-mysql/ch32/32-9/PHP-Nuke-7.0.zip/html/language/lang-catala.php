<?php

/**************************************************************************/
/*                                                                        */
/* lLENGUA CATALANA By:                                                   */
/*          -=^OutOfOrder^=-                                              */
/*                                                                        */
/**************************************************************************/

define("_CHARSET","ISO-8859-1");
define("_SEARCH","Buscar");
define("_LOGIN","Login");
define("_WRITES", "va escriure");
define("_POSTEDON","Enviat el");
define("_NICKNAME","Nickname");
define("_PASSWORD","Password");
define("_WELCOMETO","Benvingut a");
define("_EDIT","Editar");
define("_DELETE","Borrar");
define("_POSTEDBY","Enviat per");
define("_READS","Lectures");
define("_GOBACK","[ <a href=\"javascript:history.go(-1)\">Tornar enrere</a> ]");
define("_COMMENTS","Cometaris");
define("_PASTARTICLES","Articles Passats");
define("_OLDERARTICLES","Articles Antics");
define("_BY","per");
define("_ON","el");
define("_LOGOUT","Sortir");
define("_WAITINGCONT","Contingut Esperant");
define("_SUBMISSIONS","Enviaments");
define("_WREVIEWS","Reviews");
define("_WLINKS","Enlla�os");
define("_EPHEMERIDS","Efem�rides");
define("_ONEDAY","Tal dia com avui...");
define("_ASREGISTERED","Encara no tens una compta? Pots <a href=\"modules.php?name=Your_Account\">crear-ne una</a>. Com a usuari registrat gaudir�s de ventatges com: seleccionar l'apari�ncia de la p�gina, configurar els comentaris i enviar els comentaris amb el teu nom.");
define("_MENUFOR","Men� de");
define("_NOBIGSTORY","Avui encara no hi ha una Gran Historia.");
define("_BIGSTORY","La Historia m�s llegida avui:");
define("_SURVEY","Enquesta");
define("_POLLS","Enquestes");
define("_PCOMMENTS","Comentaris:");
define("_RESULTS","Resultats");
define("_HREADMORE","Llegir m�s...");
define("_CURRENTLY","Actualment hi han");
define("_GUESTS","invitats,");
define("_MEMBERS","membre(s) conectat(s).");
define("_YOUARELOGGED","Ets conectat com a");
define("_YOUHAVE","Tens");
define("_PRIVATEMSG","missatge(s) privat(s).");
define("_YOUAREANON","Ets un usuari an�nim. Pots registrar-te <a href=\"modules.php?name=Your_Account\">aqu�</a>");
define("_NOTE","Nota:");
define("_ADMIN","Admin:");
define("_WERECEIVED","Hem rebut");
define("_PAGESVIEWS","impresions des de");
define("_TOPIC","T�pic");
define("_UDOWNLOADS","Desc�rrgues");
define("_VOTE","vot");
define("_VOTES","vots");
define("_MVIEWADMIN","Ver: Sols Administradors");
define("_MVIEWUSERS","Ver: Sols Usuaris Registrats");
define("_MVIEWANON","Ver: Sols Usuaris An�nims");
define("_MVIEWALL","Ver: Tots els Visitants");
define("_EXPIRELESSHOUR","Caducitat: menys d'una hora");
define("_EXPIREIN","Caduca dins de");
define("_HTTPREFERERS","HTTP Referers");
define("_UNLIMITED","Il�limitat");
define("_HOURS","Hores");
define("_RSSPROBLEM","Actualment hi ha un problema amb els titulars d'aquesta Web");
define("_SELECTLANGUAGE","Seleccionar Idioma");
define("_SELECTGUILANG","Selecciona Idioma de la Interficie:");
define("_NONE","Cap");
define("_BLOCKPROBLEM","<center>Hi Ha un problema amb aquest bloc.</center>");
define("_BLOCKPROBLEM2","<center>En aquests moments no existeix cap contingut per a aquest bloc.</center>");
define("_MODULENOTACTIVE","Perdona, aquest M�dul no est� Actiu!");
define("_NOACTIVEMODULES","M�duls Inactius");
define("_FORADMINTESTS","(Per a Probes)");
define("_BBFORUMS","Forums");
define("_ACCESSDENIED", "Acces Denegat");
define("_RESTRICTEDAREA", "Est�s intentant entrar a una �rea restringida.");
define("_MODULEUSERS", "Ho sentim molt per� aquesta secci� de la nostra web es sols per a <i>Usuaris Registrats</i><br><br>Pots registrar-te de forma gratu�ta <a href=\"modules.php?name=Your_Account&op=new_user\">aqu�</a>, Despr�s podr�s<br>accedir a aquest secci� sense restriccions. Gracias.<br><br>");
define("_MODULESADMINS", "Ho sentim molt per� aquesta secci� de la nostra web es sols per a <i>Administradors</i><br><br>");
define("_HOME","Home");
define("_HOMEPROBLEM","Hi Ha un gran problema aqu�: No tenim una p�gina d'Inici!!!");
define("_ADDAHOME","Agregar un m�dul al Home");
define("_ADD","Afegir");
define("_HOMEPROBLEMUSER","Hi ha un problema a la nostra web. Si us plau prova m�s tard.");
define("_MORENEWS","M�s a la Secci� de Noticies");
define("_ALLCATEGORIES","Totes les Categories");
define("_DATESTRING","%A, %d %B a les %T");
define("_DATESTRING2","%A, %d %B");
define("_DATE","Data");
define("_HOUR","Hora");
define("_UMONTH","M�s");
define("_YEAR","Any");
define("_JANUARY","Gener");
define("_FEBRUARY","Febrer");
define("_MARCH","Mar�");
define("_APRIL","Abril");
define("_MAY","Maig");
define("_JUNE","Juny");
define("_JULY","Juliol");
define("_AUGUST","Agost");
define("_SEPTEMBER","Setembre");
define("_OCTOBER","Octubre");
define("_NOVEMBER","Novembre");
define("_DECEMBER","Desembre");
define("_BWEL","Benvingut");
define("_BPM","Missatges Privats");
define("_BUNREAD","Sense Llegir");
define("_BREAD","Llegits");
define("_BMEMP","Membres");
define("_BLATEST","�ltim");
define("_BTD","Nous Aviu");
define("_BYD","Nous Ahir");
define("_BOVER","Total");
define("_BVISIT","Gent connectada");
define("_BVIS","Visitants");
define("_BMEM","Miembres");
define("_BTT","Total");
define("_BON","Connectats ara");
define("_BREG","Registra't");
define("_BROADCAST","Transmisio de Missatge P�blic");
define("_BROADCASTFROM","Missatge P�blic de");
define("_TURNOFFMSG","Desactivar Missatges P�blics");
define("_YES","Si");
define("_NO","No");
define("_INVISIBLEMODULES","M�duls Invisibles");
define("_ACTIVEBUTNOTSEE","(Actius amb nom invisible)");
define("_THISISAUTOMATED","Aquest �s un missatge automatizat per a informar-l'hi que el seu banner publicitari la nostra web ha finalitzat en aquests moments.");
define("_THERESULTS","Els resultats de la seva campanya publicitaria s�n els seg�ents:");
define("_TOTALIMPRESSIONS","Total d'Impresions Realitzades:");
define("_CLICKSRECEIVED","Clicks Rebuts:");
define("_IMAGEURL","URL de l'Imatgen:");
define("_CLICKURL","URL del Click:");
define("_ALTERNATETEXT","Text Alternatiu:");
define("_HOPEYOULIKED","Esperem que hagi fru�t amb el nostre servei desitjant tenir-lo novament com a cliente nostre molt prompte.");
define("_THANKSUPPORT","Gracies pel seu Soport");
define("_TEAM","Administraci�");
define("_BANNERSFINNISHED","Banners Acavats");
define("_MODREQLINKS","Mod. Links");
define("_BROKENLINKS","Enlla�os trencats");
define("_MODREQDOWN","Mod. Desc�rregues");
define("_BROKENDOWN","Desc�rregues Trencades");
define("_PAGEGENERATION","P�gina Generada al:");
define("_SECONDS","Segons");
define("_CHAT","Chat");
define("_REGISTERED","Registered");
define("_CHATGUESTS","Guests");
define("_USERSTALKINGNOW","Users Talking Now");
define("_ENTERTOCHAT","Enter To Chat");
define("_CHATROOMS","Available Rooms");
define("_SECURITYCODE","Security Code");
define("_TYPESECCODE","Type Security Code");
define("_ASSOTOPIC","Associated Topics");

/*****************************************************/
/* Function to translate Datestrings                 */
/*****************************************************/

function translate($phrase) {
    switch($phrase) {
        case "xdatestring":        $tmp = "%A, %B %d @ %T %Z"; break;
        case "linksdatestring":        $tmp = "%d-%b-%Y"; break;
        case "xdatestring2":        $tmp = "%A, %B %d"; break;
        default:                $tmp = "$phrase"; break;
    }
    return $tmp;
}

?>