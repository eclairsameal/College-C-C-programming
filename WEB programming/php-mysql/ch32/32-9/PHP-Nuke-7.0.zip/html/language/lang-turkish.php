<?php

/**************************************************************************/
/* PHP-NUKE: Advanced Content Management System                           */
/* ============================================                           */
/*                                                                        */
/* Php-Nuke'nin s�rekli geli�mesine ba�l� olarak eski T�rk�e dil dosyalar�*/
/* g�ncelli�ini yitirdi�i i�in "HighLAndeR" taraf�ndan "MaXCoDeR"in       */
/* yapm�� oldu�u �eviriler g�ncelle�tirilip yeni �eviriler eklenmi�tir... */
/*                                                                        */
/* NOT: Yard�mlar� i�in Gurol400(gurol400@propc.org)'e te�ekk�rler.       */
/*                                                                        */
/* T�rk�e �evirmeni: HighLAndeR                                           */
/* Email: highlander@propc.org ICQ#: 110930777 	URL: http://www.propc.org */
/*                                                                        */
/* T�rk�e �evirmeni: Selim "MaXCoDeR" �umlu                               */
/* Mail:webmaster@pcnet.com.tr ICQ:19648424 URL: http://www.turknuke.com  */
/**************************************************************************/

define("_CHARSET","windows-1254");
define("_SEARCH","Ara");
define("_LOGIN","Giri�");
define("_WRITES","bildirdi:");
define("_POSTEDON","Tarih:");
define("_NICKNAME","�ye Ad�");
define("_PASSWORD","�ifre");
define("_WELCOMETO","Ho�geldiniz:");
define("_EDIT","D�zenle");
define("_DELETE","Sil");
define("_POSTEDBY","G�nderen:");
define("_READS","okuma");
define("_GOBACK","[ <a href=\"javascript:history.go(-1)\">Geri D�n</a> ]");
define("_COMMENTS","yorum");
define("_PASTARTICLES","Ge�mi� Haberler");
define("_OLDERARTICLES","Eski Haberler");
define("_BY","G�nderen:");
define("_ON","Tarih:");
define("_LOGOUT","��k��");
define("_WAITINGCONT","Bekleyen ��erik");
define("_SUBMISSIONS","Haber");
define("_WREVIEWS","�zlenim");
define("_WLINKS","Ba�lant�");
define("_EPHEMERIDS","Ge�iciler");
define("_ONEDAY","Tarihte Bu G�n...");
define("_ASREGISTERED","Hala hesab�n�z yok mu? Hemen <a href=\"modules.php?name=Your_Account&op=new_user\">a�abilirsiniz</a>. Kay�tl� bir kullan�c� olarak tema y�netici, yorum ayarlar� ve isminizle yorum g�nderme gibi avantajlara sahip olacaks�n�z.");
define("_MENUFOR","Men�:");
define("_NOBIGSTORY","Bu g�n i�in hen�z �nemli bir haber yok.");
define("_BIGSTORY","G�n�n en �ok okunan haberi:");
define("_SURVEY","Anket");
define("_POLLS","Anketler");
define("_PCOMMENTS","Yorum:");
define("_RESULTS","Sonu�lar");
define("_HREADMORE","devam�...");
define("_CURRENTLY","�u an sitede,");
define("_GUESTS","ziyaret�i ve");
define("_MEMBERS","�ye bulunuyor.");
define("_YOUARELOGGED","Merhaba");
define("_YOUHAVE","");
define("_PRIVATEMSG","�zel mesaj�n var.");
define("_YOUAREANON","Hen�z �ye de�ilseniz, <a href=\"modules.php?name=Your_Account&op=new_user\">Buraya</a> t�klayarak �cretsiz kay�t olabilirsiniz.");
define("_NOTE","Not:");
define("_ADMIN","Y�netici:");
define("_WERECEIVED","�u ana kadar");
define("_PAGESVIEWS","sayfa izlenimi ald�k. Ba�lang��:");
define("_TOPIC","Konu");
define("_UDOWNLOADS","�ndirme");
define("_VOTE","Oy Ver");
define("_VOTES","Toplam Oy");
define("_MVIEWADMIN","�zle: Sadece Edit�rler");
define("_MVIEWUSERS","�zle: Sadece Kay�tl� Kullan�c�lar");
define("_MVIEWANON","�zle: Sadece Anonim Kullan�c�lar");
define("_MVIEWALL","�zle: T�m Ziyaret�iler");
define("_EXPIRELESSHOUR","�mha: 1 saat i�inde");
define("_EXPIREIN","�mha:");
define("_HTTPREFERERS","HTTP �nerenler");
define("_UNLIMITED","Limitsiz");
define("_HOURS","Saat");
define("_RSSPROBLEM","�u an bu sitenin ba�l�klar�nda problem var");
define("_SELECTLANGUAGE","Dil Se�in");
define("_SELECTGUILANG","Site Lisan�n� Se�in");
define("_NONE","Yok");
define("_BLOCKPROBLEM","<center>�u an bu blokta bir sorun var.</center>");
define("_BLOCKPROBLEM2","<center>�u an bu blo�un i�eri�i yok.</center>");
define("_MODULENOTACTIVE","�sg�n�m, bu mod�l aktif de�il!");
define("_NOACTIVEMODULES","Pasif Mod�ller");
define("_FORADMINTESTS","(Y�netici tesleri i�in)");
define("_BBFORUMS","Forumlar�");
define("_ACCESSDENIED", "Eri�im Engellendi");
define("_RESTRICTEDAREA", "K�s�tl� bir alana ula�maya �al���yorsunuz.");
define("_MODULEUSERS", "�zg�n�z, sitemizin bu b�l�m� <i>sadece kay�tl� kullan�c�lar</i> i�indir.<br><br><a href=\"modules.php?name=Your_Account&op=new_user\">Buraya</a> t�klayarak �cretsiz kay�t olabilir, daha sonra<br>bu b�l�me k�s�tlamalarla kar��la�madan eri�ebilirsiniz. Te�ekk�rler.<br><br>");
define("_MODULESADMINS", "�zg�n�z, sitemizin bu b�l�m� <i>sadece edit�rler</i> i�indir.<br><br>");
define("_HOME","Ana Sayfa");
define("_HOMEPROBLEM","�nemli bir sorunumuz var: Ana Sayfa yok!!!");
define("_ADDAHOME","Ana Sayfaya bir Mod�l ekle");
define("_HOMEPROBLEMUSER","�u an ana sayfada bir sorun var. L�tfen daha sonra tekrar deneyin.");
define("_MORENEWS","Devam� Haberler B�l�m�nde");
define("_ALLCATEGORIES","T�m Kategoriler");
define("_DATESTRING","%d.%m.20%y Saat: %H:%M");
define("_DATESTRING2","%d.%m.%y");
define("_DATE","Tarih");
define("_HOUR","Saat");
define("_UMONTH","Ay");
define("_YEAR","Y�l");
define("_JANUARY","Ocak");
define("_FEBRUARY","�ubat");
define("_MARCH","Mart");
define("_APRIL","Nisan");
define("_MAY","May�s");
define("_JUNE","Haziran");
define("_JULY","Temmuz");
define("_AUGUST","A�ustos");
define("_SEPTEMBER","Eyl�l");
define("_OCTOBER","Ekim");
define("_NOVEMBER","Kas�m");
define("_DECEMBER","Aral�k");
define("_BWEL","Ho�geldin");
define("_BPM","�zel Mesajlar");
define("_BUNREAD","Okunmam��");
define("_BREAD","Okunmu�");
define("_BMEMP","�yelik");
define("_BLATEST","Son �ye");
define("_BTD","Bug�n");
define("_BYD","D�n");
define("_BOVER","Toplam");
define("_BVISIT","�u An Ba�l�");
define("_BVIS","Ziyaret�i");
define("_BMEM","�ye");
define("_BTT","Toplam");
define("_BON","�u An Ba�l�");
define("_BREG","Kay�t Ol");
define("_BROADCAST","Herkese A��k Mesaj Yay�nla");
define("_BROADCASTFROM","Genel Mesaj:");
define("_TURNOFFMSG","Herkese A��k Mesajlar� Kapat");
define("_JOURNAL","G�nl�k");
define("_READMYJOURNAL","G�nl���m� Oku");
define("_ADD","Ekle");
define("_YES","Evet");
define("_NO","Hay�r");
define("_INVISIBLEMODULES","G�r�nmez Mod�ller");
define("_ACTIVEBUTNOTSEE","(Aktif ama g�r�nmez link)");
define("_THISISAUTOMATED","Bu, sitemizdeki banner reklam yay�n�n�z�n �u an itibari ile bitti�ini bildiren otomatik bir mesajd�r.");
define("_THERESULTS","Reklam�n�z�n sonu�lar� a�a��dad�r");
define("_TOTALIMPRESSIONS","Yap�lan Toplam G�ster:");
define("_CLICKSRECEIVED","Al�nan T�klama:");
define("_IMAGEURL","Grafik Adresi");
define("_CLICKURL","T�klama Adresi:");
define("_ALTERNATETEXT","Alternatif Metin:");
define("_HOPEYOULIKED","Servisimizden memnun kald���n�z� umuyoruz. Sizi tekrar reklam m��terimiz olarak g�rmeyi diliyoruz.");
define("_THANKSUPPORT","Deste�iniz i�in te�ekk�rler");
define("_TEAM","Tak�m�");
define("_BANNERSFINNISHED","Bitmi� Banner Reklamlar�");
define("_MODREQLINKS","Ba�lant� Y�netimi");
define("_BROKENLINKS","K�r�k Ba�lant�lar");
define("_MODREQDOWN","Dosya Y�netimi");
define("_BROKENDOWN","K�r�k Dosyalar");
define("_PAGEGENERATION","Sayfa �retimi:");
define("_SECONDS","Saniye");
define("_YOUHAVEONEMSG","Yeni 1 �zel Mesaj�n�z Var");
define("_YOUHAVE","Senin");
define("_NEWPMSG","NYeni �zel Mesaj�n Var");
define("_CONTRIBUTEDBY","Katk�da Bulundu");
define("_CHAT","Chat");
define("_REGISTERED","Kay�tl�");
define("_CHATGUESTS","Ziyaret�iler");
define("_USERSTALKINGNOW","�imdi Kullan�c�larla Konu�");
define("_ENTERTOCHAT","Chate Gir");
define("_CHATROOMS","Uygun Chat Odalar�");
define("_SECURITYCODE","G�venlik Kodu");
define("_TYPESECCODE","G�venlik Kodunu Girin");
define("_ASSOTOPIC","�lgili Konular");

define("_ADDITIONALYGRP","�lave olarak bu mod�l Kullan�c� grubuna aittir");
define("_YOUHAVEPOINTS","Site i�eri�indeki Kat�l�m�n�zdan verilen puanlar:");

/*****************************************************/
/* Function to translate Datestrings                 */
/*****************************************************/

function translate($phrase) {
    switch($phrase) {
	case "xdatestring":	$tmp = "%A, %B %d @ %T %Z"; break;
	case "linksdatestring":	$tmp = "%d-%b-%Y"; break;
	case "xdatestring2":	$tmp = "%A, %B %d"; break;
	default:		$tmp = "$phrase"; break;
    }
    return $tmp;
}

?>