<?php

/************************************************************************/
/* PHP-NUKE: Web Portal System                                          */
/* ===========================                                          */
/*                                                                      */
/* Link to the phpBB2 forum admin menu                                  */
/*                                                                      */
/* Copyright (c) 2002 by Tom Nitzschner (tom@toms-home.com)             */
/* http://bbtonuke.sourceforge.net                                      */
/* http://www.toms-home.com                                             */
/*									*/
/*   As always, make a backup before messing with anything. All code    */
/*   release by me is considered sample code only. It may be fully      */
/*   functual, but you use it at your own risk, if you break it,        */
/*   you get to fix it too. No waranty is given or implied.             */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/


if (!eregi("admin.php", $_SERVER['PHP_SELF'])) { die ("Access Denied"); }
$aid = trim($aid);
$result = mysql_query("select radminforum, radminsuper from ".$prefix."_authors where aid='$aid'");
list($radminforum, $radminsuper) = mysql_fetch_row($result);

if ($radminsuper == 1 OR $radminforum == 1) {

	switch($op) {
	
		case "forums":
		Header("Location: modules/Forums/admin/index.php");
	}

			
} else {
    echo "Access Denied";
}

?>