<?php

if ($radminsuper==1) {
    adminmenu("admin.php?op=optimize", "Optimize DB", "optimize.gif");
}

?>